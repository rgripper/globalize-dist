Globalize.load({
  "main": {
    "ko": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10931 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-03 21:52:43 -0500 (Wed, 03 Sep 2014) $"
        },
        "language": "ko"
      },
      "delimiters": {
        "quotationStart": "“",
        "quotationEnd": "”",
        "alternateQuotationStart": "‘",
        "alternateQuotationEnd": "’"
      }
    }
  }
}
)