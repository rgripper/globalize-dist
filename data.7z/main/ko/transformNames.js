Globalize.load({
  "main": {
    "ko": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10931 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-03 21:52:43 -0500 (Wed, 03 Sep 2014) $"
        },
        "language": "ko"
      },
      "localeDisplayNames": {
        "transformNames": {
          "BGN": "미국 지명위원회(BGN)",
          "Numeric": "숫자",
          "Tone": "성조",
          "UNGEGN": "유엔지명전문가회의(UNGEGN)",
          "x-Accents": "악센트",
          "x-Fullwidth": "전각",
          "x-Halfwidth": "반각",
          "x-Jamo": "자모",
          "x-Pinyin": "병음",
          "x-Publishing": "게시"
        }
      }
    }
  }
}
)