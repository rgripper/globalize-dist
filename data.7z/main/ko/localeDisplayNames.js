Globalize.load({
  "main": {
    "ko": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10931 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-03 21:52:43 -0500 (Wed, 03 Sep 2014) $"
        },
        "language": "ko"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0}({1})",
          "localeSeparator": "{0}, {1}",
          "localeKeyTypePattern": "{0}: {1}"
        },
        "keys": {
          "calendar": "달력",
          "colAlternate": "기호 정렬 무시",
          "colBackwards": "악센트 역순 정렬",
          "colCaseFirst": "대문자/소문자 순서",
          "colCaseLevel": "대/소문자 구분 정렬",
          "colHiraganaQuaternary": "가나 정렬",
          "colNormalization": "표준 정렬",
          "colNumeric": "숫자 정렬",
          "colStrength": "정렬 강도",
          "collation": "정렬 순서",
          "currency": "통화",
          "numbers": "숫자",
          "timezone": "시간대",
          "va": "방언",
          "variableTop": "기호로 정렬",
          "x": "공개 여부"
        },
        "types": {
          "numbers": {
            "arab": "아라비아-인도식 숫자",
            "arabext": "확장형 아라비아-인도식 숫자",
            "armn": "아르메니아 숫자",
            "armnlow": "아르메니아 소문자 숫자",
            "bali": "발리 숫자",
            "beng": "뱅골 숫자"
          },
          "collation": {
            "big5han": "중국어 번체 정렬 순서 (Big5)"
          },
          "numbers": {
            "brah": "브라미 숫자"
          },
          "calendar": {
            "buddhist": "불교력"
          },
          "numbers": {
            "cakm": "챠크마 숫자",
            "cham": "참 숫자"
          },
          "calendar": {
            "chinese": "중국력",
            "coptic": "콥트력",
            "dangi": "단기력"
          },
          "numbers": {
            "deva": "데바나가리 숫자"
          },
          "collation": {
            "dictionary": "사전 정렬순",
            "ducet": "기본 유니코드 정렬 순서",
            "eor": "eor"
          },
          "numbers": {
            "ethi": "에티오피아 숫자"
          },
          "calendar": {
            "ethiopic": "에티오피아력",
            "ethiopic-amete-alem": "에티오피아 아메테 알렘력"
          },
          "numbers": {
            "finance": "재무 숫자",
            "fullwide": "전체 숫자"
          },
          "collation": {
            "gb2312han": "중국어 간체 정렬 순서 (GB2312)"
          },
          "numbers": {
            "geor": "그루지아 숫자"
          },
          "calendar": {
            "gregorian": "태양력"
          },
          "numbers": {
            "grek": "그리스 숫자",
            "greklow": "그리스어 소문자 숫자",
            "gujr": "구자라트 숫자",
            "guru": "굴묵키 숫자",
            "hanidec": "중국어 십진 숫자",
            "hans": "중국어 간체 숫자",
            "hansfin": "중국어 간체 재무 숫자",
            "hant": "중국어 번체 숫자",
            "hantfin": "중국어 번체 재무 숫자",
            "hebr": "히브리 숫자"
          },
          "calendar": {
            "hebrew": "히브리력"
          },
          "colStrength": {
            "identical": "모두 정렬"
          },
          "calendar": {
            "indian": "인도력",
            "islamic": "이슬람력",
            "islamic-civil": "이슬람 상용력",
            "islamic-rgsa": "islamic-rgsa",
            "islamic-tbla": "islamic-tbla",
            "islamic-umalqura": "islamic-umalqura",
            "iso8601": "ISO-8601 달력",
            "japanese": "일본력"
          },
          "numbers": {
            "java": "자바 숫자",
            "jpan": "일본 숫자",
            "jpanfin": "일본 재무 숫자",
            "kali": "카야 리식 숫자",
            "khmr": "크메르 숫자",
            "knda": "칸나다 숫자",
            "lana": "타이 탐 호라 숫자",
            "lanatham": "타이 탐탐 숫자",
            "laoo": "라오 숫자",
            "latn": "서양 숫자",
            "lepc": "렙차 숫자",
            "limb": "림부 숫자"
          },
          "colCaseFirst": {
            "lower": "첫 소문자 정렬"
          },
          "numbers": {
            "mlym": "말라얄람 숫자",
            "mong": "몽골 숫자",
            "mtei": "메이테이 마옉 숫자",
            "mymr": "미얀마 숫자",
            "mymrshan": "미얀마 샨 숫자",
            "native": "기본 숫자",
            "nkoo": "nkoo"
          },
          "colBackwards": {
            "no": "악센트 일반 정렬"
          },
          "colCaseFirst": {
            "no": "일반 대/소문자 정렬 순서"
          },
          "colCaseLevel": {
            "no": "대/소문자 무시 정렬"
          },
          "colHiraganaQuaternary": {
            "no": "가나 별도 정렬"
          },
          "colNormalization": {
            "no": "표준화 없이 정렬"
          },
          "colNumeric": {
            "no": "숫자별 정렬"
          },
          "colAlternate": {
            "non-ignorable": "기호 정렬"
          },
          "numbers": {
            "olck": "올치키 숫자",
            "orya": "오리야 숫자",
            "osma": "오스마냐 숫자"
          },
          "calendar": {
            "persian": "페르시안력"
          },
          "collation": {
            "phonebook": "전화번호부순",
            "phonetic": "소리나는 대로 정렬 순서",
            "pinyin": "병음순"
          },
          "colStrength": {
            "primary": "기본 문자만 정렬",
            "quaternary": "악센트/대소문자/전반각/가나 정렬"
          },
          "collation": {
            "reformed": "개정 정렬순"
          },
          "calendar": {
            "roc": "대만력"
          },
          "numbers": {
            "roman": "로마 숫자",
            "romanlow": "로마 소문자 숫자",
            "saur": "사우라슈트라 숫자"
          },
          "collation": {
            "search": "범용 검색",
            "searchjl": "한글 자음으로 검색"
          },
          "colStrength": {
            "secondary": "악센트 정렬"
          },
          "colAlternate": {
            "shifted": "기호 무시 정렬"
          },
          "numbers": {
            "shrd": "샤라다 숫자",
            "sora": "sora"
          },
          "collation": {
            "standard": "표준 정렬 순서",
            "stroke": "자획순"
          },
          "numbers": {
            "sund": "순다 숫자",
            "takr": "takr",
            "talu": "talu",
            "taml": "타밀어 숫자",
            "tamldec": "타밀 숫자",
            "telu": "텔루구 숫자"
          },
          "colStrength": {
            "tertiary": "악센트/대소문자/전반각 정렬"
          },
          "numbers": {
            "thai": "태국 숫자",
            "tibt": "티벳 숫자"
          },
          "collation": {
            "traditional": "전통 역법"
          },
          "numbers": {
            "traditional": "전통적인 숫자"
          },
          "collation": {
            "unihan": "부수순"
          },
          "colCaseFirst": {
            "upper": "대문자 우선 정렬"
          },
          "numbers": {
            "vaii": "바이 숫자"
          },
          "colBackwards": {
            "yes": "악센트 역순 정렬"
          },
          "colCaseLevel": {
            "yes": "대/소문자 구분 정렬"
          },
          "colHiraganaQuaternary": {
            "yes": "가나를 다르게 정렬"
          },
          "colNormalization": {
            "yes": "유니코드 표준화 정렬"
          },
          "colNumeric": {
            "yes": "숫자 정렬"
          },
          "collation": {
            "zhuyin": "zhuyin"
          }
        },
        "codePatterns": {
          "language": "언어: {0}",
          "script": "스크립트: {0}",
          "territory": "지역: {0}"
        }
      }
    }
  }
}
)