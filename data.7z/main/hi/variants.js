Globalize.load({
  "main": {
    "hi": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "hi"
      },
      "localeDisplayNames": {
        "variants": {
          "1606NICT": "1606NICT",
          "1694ACAD": "1694ACAD",
          "1901": "पारम्पारिक जर्मन वर्तनी",
          "1959ACAD": "1959ACAD",
          "1994": "1994",
          "1996": "जर्मेनी की 1996 वर्तनी",
          "ALALC97": "ALALC97",
          "ALUKU": "ALUKU",
          "AREVELA": "पूर्वी अर्मेनियाई",
          "AREVMDA": "AREVMDA",
          "BAKU1926": "BAKU1926",
          "BALANKA": "BALANKA",
          "BARLA": "BARLA",
          "BAUDDHA": "BAUDDHA",
          "BISCAYAN": "BISCAYAN",
          "BISKE": "BISKE",
          "BOHORIC": "BOHORIC",
          "BOONT": "BOONT",
          "DAJNKO": "DAJNKO",
          "EKAVSK": "EKAVSK",
          "EMODENG": "EMODENG",
          "FONIPA": "FONIPA",
          "FONUPA": "FONUPA",
          "FONXSAMP": "FONXSAMP",
          "HEPBURN": "HEPBURN",
          "HOGNORSK": "HOGNORSK",
          "IJEKAVSK": "IJEKAVSK",
          "ITIHASA": "ITIHASA",
          "JAUER": "JAUER",
          "JYUTPING": "JYUTPING",
          "KKCOR": "KKCOR",
          "KSCOR": "KSCOR",
          "LAUKIKA": "LAUKIKA",
          "LIPAW": "LIPAW",
          "LUNA1918": "LUNA1918",
          "METELKO": "METELKO",
          "MONOTON": "एकस्वरीय",
          "NDYUKA": "NDYUKA",
          "NEDIS": "NEDIS",
          "NJIVA": "जीवा बोली",
          "NULIK": "NULIK",
          "OSOJS": "OSOJS",
          "PAMAKA": "PAMAKA",
          "PETR1708": "PETR1708",
          "PINYIN": "पिनयिन रोमानाइज़ेशन",
          "POLYTON": "बहुस्वरीय",
          "POSIX": "कम्प्यूटर",
          "PUTER": "PUTER",
          "REVISED": "संशोधित वर्तनी",
          "RIGIK": "RIGIK",
          "ROZAJ": "ROZAJ",
          "RUMGR": "RUMGR",
          "SAAHO": "SAAHO",
          "SCOTLAND": "SCOTLAND",
          "SCOUSE": "SCOUSE",
          "SOLBA": "SOLBA",
          "SOTAV": "SOTAV",
          "SURMIRAN": "SURMIRAN",
          "SURSILV": "SURSILV",
          "SUTSILV": "SUTSILV",
          "TARASK": "TARASK",
          "UCCOR": "UCCOR",
          "UCRCOR": "UCRCOR",
          "ULSTER": "ULSTER",
          "UNIFON": "UNIFON",
          "VAIDIKA": "VAIDIKA",
          "VALENCIA": "VALENCIA",
          "VALLADER": "VALLADER",
          "WADEGILE": "वेड-गाइल्स रोमनाइज़ेशन"
        }
      }
    }
  }
}
)