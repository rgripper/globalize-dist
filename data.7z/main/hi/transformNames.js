Globalize.load({
  "main": {
    "hi": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "hi"
      },
      "localeDisplayNames": {
        "transformNames": {
          "BGN": "BGN",
          "Numeric": "सांख्यिक",
          "Tone": "स्वर",
          "UNGEGN": "UNGEGN",
          "x-Accents": "स्वराघात",
          "x-Fullwidth": "पूर्ण-चौड़ाई",
          "x-Halfwidth": "आधी-चौड़ाई",
          "x-Jamo": "जामो",
          "x-Pinyin": "पिनयिन",
          "x-Publishing": "प्रकाशन"
        }
      }
    }
  }
}
)