Globalize.load({
  "main": {
    "hi": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "hi"
      },
      "localeDisplayNames": {
        "measurementSystemNames": {
          "US": "यूएस",
          "metric": "मीट्रिक",
          "UK": "यूके"
        }
      }
    }
  }
}
)