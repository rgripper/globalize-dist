Globalize.load({
  "main": {
    "hr": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "hr"
      },
      "localeDisplayNames": {
        "variants": {
          "1606NICT": "kasni srednjofrancuski do 1606.",
          "1694ACAD": "rani moderni francuski",
          "1901": "tradicionalan njemački pravopis",
          "1959ACAD": "akademski",
          "1994": "standardizirani resian pravopis",
          "1996": "njemačka ortografija iz 1996.",
          "ALALC97": "ALALC97",
          "ALUKU": "aluku dijalekt",
          "AREVELA": "istočno-armenijski",
          "AREVMDA": "zapadno-armenijski",
          "BAKU1926": "unificirana turska abeceda",
          "BALANKA": "BALANKA",
          "BARLA": "BARLA",
          "BAUDDHA": "BAUDDHA",
          "BISCAYAN": "BISCAYAN",
          "BISKE": "san giorgio/bila dijalekt",
          "BOHORIC": "BOHORIC",
          "BOONT": "boontling",
          "DAJNKO": "DAJNKO",
          "EKAVSK": "EKAVSK",
          "EMODENG": "rani moderni engleski",
          "FONIPA": "IPA fonetika",
          "FONUPA": "UPA fonetika",
          "FONXSAMP": "FONXSAMP",
          "HEPBURN": "HEPBURN",
          "HOGNORSK": "HOGNORSK",
          "IJEKAVSK": "IJEKAVSK",
          "ITIHASA": "ITIHASA",
          "JAUER": "JAUER",
          "JYUTPING": "JYUTPING",
          "KKCOR": "Uobičajeni pravopis",
          "KSCOR": "standardna ortografija",
          "LAUKIKA": "LAUKIKA",
          "LIPAW": "lipovački dijalekt resian jezika",
          "LUNA1918": "LUNA1918",
          "METELKO": "metelčica",
          "MONOTON": "monotono",
          "NDYUKA": "NDYUKA",
          "NEDIS": "natisone dijalekt",
          "NJIVA": "Gniva/Njiva dijalekt",
          "NULIK": "moderni volapuk",
          "OSOJS": "oseacco/osojane dijalekt",
          "PAMAKA": "pamaka dijalekt",
          "PETR1708": "PETR1708",
          "PINYIN": "Pinyin romanizacija",
          "POLYTON": "politono",
          "POSIX": "Računalo",
          "PUTER": "PUTER",
          "REVISED": "izmijenjen pravopis",
          "RIGIK": "RIGIK",
          "ROZAJ": "resian",
          "RUMGR": "RUMGR",
          "SAAHO": "saho",
          "SCOTLAND": "škotski standardni engleski",
          "SCOUSE": "scouse",
          "SOLBA": "stolvizza/solbica dijalekt",
          "SOTAV": "SOTAV",
          "SURMIRAN": "SURMIRAN",
          "SURSILV": "SURSILV",
          "SUTSILV": "SUTSILV",
          "TARASK": "taraskievica pravopis",
          "UCCOR": "ujednačena ortografija",
          "UCRCOR": "ujednačena revidirana ortografija",
          "ULSTER": "ULSTER",
          "UNIFON": "UNIFON",
          "VAIDIKA": "VAIDIKA",
          "VALENCIA": "valencijski",
          "VALLADER": "VALLADER",
          "WADEGILE": "Wade-Giles romanizacija"
        }
      }
    }
  }
}
)