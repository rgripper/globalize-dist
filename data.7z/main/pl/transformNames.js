Globalize.load({
  "main": {
    "pl": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10895 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-01 13:57:54 -0500 (Mon, 01 Sep 2014) $"
        },
        "language": "pl"
      },
      "localeDisplayNames": {
        "transformNames": {
          "BGN": "BGN",
          "Numeric": "Liczbowe",
          "Tone": "Ton",
          "UNGEGN": "UNGEGN",
          "x-Accents": "Akcenty",
          "x-Fullwidth": "Pełna szerokość",
          "x-Halfwidth": "Połowa szerokości",
          "x-Jamo": "Jamo",
          "x-Pinyin": "Pinyin",
          "x-Publishing": "Druk"
        }
      }
    }
  }
}
)