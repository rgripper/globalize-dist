Globalize.load({
  "main": {
    "pl": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10895 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-01 13:57:54 -0500 (Mon, 01 Sep 2014) $"
        },
        "language": "pl"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0} ({1})",
          "localeSeparator": "{0}, {1}",
          "localeKeyTypePattern": "{0}: {1}"
        },
        "keys": {
          "calendar": "kalendarz",
          "colAlternate": "Sortowanie ignorujące symbole",
          "colBackwards": "Odwrotne sortowanie ze znakami akcentowanymi",
          "colCaseFirst": "Porządek wielkie/małe litery",
          "colCaseLevel": "Sortowanie uwzględniające wielkość liter",
          "colHiraganaQuaternary": "Sortowanie Kana",
          "colNormalization": "Sortowanie znormalizowane",
          "colNumeric": "Sortowanie numeryczne",
          "colStrength": "Siła sortowania",
          "collation": "Porządek sortowania",
          "currency": "waluta",
          "numbers": "cyfry",
          "timezone": "Strefa czasowa",
          "va": "Wariant regionalny",
          "variableTop": "Sortuj jak symbole",
          "x": "Do prywatnego użytku"
        },
        "types": {
          "numbers": {
            "arab": "cyfry arabsko-indyjskie",
            "arabext": "rozszerzone cyfry arabsko-indyjskie",
            "armn": "cyfry ormiańskie",
            "armnlow": "cyfry ormiańskie (małe litery)",
            "bali": "bali",
            "beng": "cyfry bengalskie"
          },
          "collation": {
            "big5han": "chiński tradycyjny porządek sortowania - Big5"
          },
          "numbers": {
            "brah": "brah"
          },
          "calendar": {
            "buddhist": "kalendarz buddyjski"
          },
          "numbers": {
            "cakm": "cakm",
            "cham": "cham"
          },
          "calendar": {
            "chinese": "kalendarz chiński",
            "coptic": "Kalendarz koptyjski",
            "dangi": "kalendarz dangi"
          },
          "numbers": {
            "deva": "cyfry dewanagari"
          },
          "collation": {
            "dictionary": "sortowanie słownikowe",
            "ducet": "Domyślna kolejność sortowania Unicode",
            "eor": "europejskie reguły określania kolejności"
          },
          "numbers": {
            "ethi": "cyfry etiopskie"
          },
          "calendar": {
            "ethiopic": "Kalendarz etiopski",
            "ethiopic-amete-alem": "Kalendarz etiopski Amete Alem"
          },
          "numbers": {
            "finance": "Liczebniki księgowe",
            "fullwide": "cyfry o pełnej szerokości"
          },
          "collation": {
            "gb2312han": "chiński uproszczony porządek sortowania - GB2312"
          },
          "numbers": {
            "geor": "cyfry gruzińskie"
          },
          "calendar": {
            "gregorian": "kalendarz gregoriański"
          },
          "numbers": {
            "grek": "cyfry greckie",
            "greklow": "cyfry greckie (małe litery)",
            "gujr": "cyfry gudżarati",
            "guru": "cyfry gurmukhi",
            "hanidec": "chińskie cyfry dziesiętne",
            "hans": "uproszczone cyfry chińskie",
            "hansfin": "uproszczone chińskie cyfry księgowe",
            "hant": "tradycyjne cyfry chińskie",
            "hantfin": "tradycyjne chińskie cyfry księgowe",
            "hebr": "cyfry hebrajskie"
          },
          "calendar": {
            "hebrew": "kalendarz hebrajski"
          },
          "colStrength": {
            "identical": "Sortuj wszystko"
          },
          "calendar": {
            "indian": "narodowy kalendarz hinduski",
            "islamic": "kalendarz islamski (metoda wzrokowa)",
            "islamic-civil": "kalendarz islamski (metoda obliczeniowa)",
            "islamic-rgsa": "kalendarz islamski (Arabia Saudyjska, metoda wzrokowa)",
            "islamic-tbla": "kalendarz islamski (metoda obliczeniowa, epoka astronomiczna)",
            "islamic-umalqura": "kalendarz islamski (Umm al-Kura)",
            "iso8601": "kalendarz ISO-8601",
            "japanese": "kalendarz japoński"
          },
          "numbers": {
            "java": "java",
            "jpan": "cyfry japońskie",
            "jpanfin": "japońskie cyfry księgowe",
            "kali": "kali",
            "khmr": "cyfry khmerskie",
            "knda": "cyfry kannada",
            "lana": "lana",
            "lanatham": "lanatham",
            "laoo": "cyfry laotańskie",
            "latn": "cyfry arabskie",
            "lepc": "lepc",
            "limb": "limb"
          },
          "colCaseFirst": {
            "lower": "Sortowanie od małych liter"
          },
          "numbers": {
            "mlym": "cyfry malajalam",
            "mong": "Cyfry mongolskie",
            "mtei": "mtei",
            "mymr": "cyfry birmańskie",
            "mymrshan": "mymrshan",
            "native": "Cyfry macierzyste",
            "nkoo": "nkoo"
          },
          "colBackwards": {
            "no": "Zwykłe sortowanie znaków akcentowanych"
          },
          "colCaseFirst": {
            "no": "Sortowanie z zachowaniem zwykłej kolejności wielkości liter"
          },
          "colCaseLevel": {
            "no": "Sortowanie bez rozróżniania wielkości liter"
          },
          "colHiraganaQuaternary": {
            "no": "Osobne sortowanie kana"
          },
          "colNormalization": {
            "no": "Sortowanie bez normalizacji"
          },
          "colNumeric": {
            "no": "Oddzielne sortowanie cyfr"
          },
          "colAlternate": {
            "non-ignorable": "Sortowanie symboli"
          },
          "numbers": {
            "olck": "olck",
            "orya": "cyfry orija",
            "osma": "osma"
          },
          "calendar": {
            "persian": "Kalendarz perski"
          },
          "collation": {
            "phonebook": "porządek sortowania książki telefonicznej",
            "phonetic": "sortowanie fonetyczne",
            "pinyin": "porządek sortowania pinyin"
          },
          "colStrength": {
            "primary": "Sortowanie tylko liter podstawowych",
            "quaternary": "Sortowanie znaków akcentowanych/wielkości liter/szerokości/kana"
          },
          "collation": {
            "reformed": "sortowanie zreformowane"
          },
          "calendar": {
            "roc": "kalendarz Republiki Chińskiej"
          },
          "numbers": {
            "roman": "cyfry rzymskie",
            "romanlow": "cyfry rzymskie (małe litery)",
            "saur": "saur"
          },
          "collation": {
            "search": "uniwersalny porządek sortowania",
            "searchjl": "Wyszukiwanie według początkowej spółgłoski hangul"
          },
          "colStrength": {
            "secondary": "Sortowanie znaków akcentowanych"
          },
          "colAlternate": {
            "shifted": "Sortowanie ignorujące symbole"
          },
          "numbers": {
            "shrd": "shrd",
            "sora": "sora"
          },
          "collation": {
            "standard": "sortowanie standardowe",
            "stroke": "porządek akcentów"
          },
          "numbers": {
            "sund": "sund",
            "takr": "takr",
            "talu": "talu",
            "taml": "cyfry tamilskie",
            "tamldec": "cyfry tamilskie",
            "telu": "cyfry telugu"
          },
          "colStrength": {
            "tertiary": "Sortowanie znaków akcentowanych/wielkości liter/szerokości"
          },
          "numbers": {
            "thai": "cyfry tajskie",
            "tibt": "cyfry tybetańskie"
          },
          "collation": {
            "traditional": "tradycyjny porządek sortowania"
          },
          "numbers": {
            "traditional": "Liczebniki tradycyjne"
          },
          "collation": {
            "unihan": "sortowanie wg kluczy i ich liczby kresek"
          },
          "colCaseFirst": {
            "upper": "Sortowanie od wielkich liter"
          },
          "numbers": {
            "vaii": "Cyfry vai"
          },
          "colBackwards": {
            "yes": "Sortowanie znaków akcentowanych w odwróconej kolejności"
          },
          "colCaseLevel": {
            "yes": "Sortowanie z rozróżnianiem wielkości liter"
          },
          "colHiraganaQuaternary": {
            "yes": "Inne sortowanie kana"
          },
          "colNormalization": {
            "yes": "Sortowanie z normalizacją unicode"
          },
          "colNumeric": {
            "yes": "Numeryczne sortowanie cyfr"
          },
          "collation": {
            "zhuyin": "zhuyin"
          }
        },
        "codePatterns": {
          "language": "Język: {0}",
          "script": "Pismo: {0}",
          "territory": "Region: {0}"
        }
      }
    }
  }
}
)