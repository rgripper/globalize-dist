Globalize.load({
  "main": {
    "en-GB": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10819 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 22:53:08 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "en",
        "territory": "001"
      },
      "localeDisplayNames": {
        "measurementSystemNames": {
          "US": "US",
          "metric": "Metric",
          "UK": "UK"
        }
      }
    }
  }
}
)