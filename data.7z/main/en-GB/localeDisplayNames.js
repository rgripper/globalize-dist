Globalize.load({
  "main": {
    "en-GB": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10819 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 22:53:08 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "en",
        "territory": "001"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0} ({1})",
          "localeSeparator": "{0}, {1}",
          "localeKeyTypePattern": "{0}: {1}"
        },
        "keys": {
          "calendar": "Calendar",
          "colAlternate": "Ignore Symbols Sorting",
          "colBackwards": "Reversed Accent Sorting",
          "colCaseFirst": "Uppercase/Lowercase Ordering",
          "colCaseLevel": "Case-Sensitive Sorting",
          "colHiraganaQuaternary": "Kana Sorting",
          "colNormalization": "Normalised Sorting",
          "colNumeric": "Numeric Sorting",
          "colReorder": "Script/Block Reordering",
          "colStrength": "Sorting Strength",
          "collation": "Sort Order",
          "currency": "Currency",
          "kv": "Highest Ignored",
          "numbers": "Numbers",
          "timezone": "Time Zone",
          "va": "Locale Variant",
          "variableTop": "Sort As Symbols",
          "x": "Private-Use"
        },
        "types": {
          "numbers": {
            "arab": "Arabic-Indic Digits",
            "arabext": "Extended Arabic-Indic Digits",
            "arabext-alt-short": "X Arabic-Indic Digits",
            "armn": "Armenian Numerals",
            "armnlow": "Armenian Lowercase Numerals",
            "bali": "Balinese Digits",
            "beng": "Bengali Digits"
          },
          "collation": {
            "big5han": "Traditional Chinese Sort Order - Big5"
          },
          "numbers": {
            "brah": "Brahmi Digits"
          },
          "calendar": {
            "buddhist": "Buddhist Calendar"
          },
          "numbers": {
            "cakm": "Chakma Digits",
            "cham": "Cham Digits"
          },
          "calendar": {
            "chinese": "Chinese Calendar",
            "coptic": "Coptic Calendar",
            "dangi": "Dangi Calendar"
          },
          "numbers": {
            "deva": "Devanagari Digits"
          },
          "collation": {
            "dictionary": "Dictionary Sort Order",
            "ducet": "Default Unicode Sort Order",
            "eor": "European Ordering Rules"
          },
          "numbers": {
            "ethi": "Ethiopic Numerals"
          },
          "calendar": {
            "ethiopic": "Ethiopic Calendar",
            "ethiopic-amete-alem": "Ethiopic Amete Alem Calendar"
          },
          "numbers": {
            "finance": "Financial Numerals",
            "fullwide": "Full-Width Digits"
          },
          "collation": {
            "gb2312han": "Simplified Chinese Sort Order - GB2312"
          },
          "numbers": {
            "geor": "Georgian Numerals"
          },
          "calendar": {
            "gregorian": "Gregorian Calendar"
          },
          "numbers": {
            "grek": "Greek Numerals",
            "greklow": "Greek Lowercase Numerals",
            "gujr": "Gujarati Digits",
            "guru": "Gurmukhi Digits",
            "hanidays": "Chinese Calendar Day-of-Month Numerals",
            "hanidec": "Chinese Decimal Numerals",
            "hans": "Simplified Chinese Numerals",
            "hansfin": "Simplified Chinese Financial Numerals",
            "hant": "Traditional Chinese Numerals",
            "hantfin": "Traditional Chinese Financial Numerals",
            "hebr": "Hebrew Numerals"
          },
          "calendar": {
            "hebrew": "Hebrew Calendar"
          },
          "colStrength": {
            "identical": "Sort All"
          },
          "calendar": {
            "indian": "Indian National Calendar",
            "islamic": "Islamic Calendar",
            "islamic-civil": "Islamic Calendar (tabular, civil epoch)",
            "islamic-rgsa": "Islamic Calendar (Saudi Arabia, sighting)",
            "islamic-tbla": "Islamic Calendar (tabular, astronomical epoch)",
            "islamic-umalqura": "Islamic Calendar (Umm al-Qura)",
            "iso8601": "ISO-8601 Calendar",
            "japanese": "Japanese Calendar"
          },
          "numbers": {
            "java": "Javanese Digits",
            "jpan": "Japanese Numerals",
            "jpanfin": "Japanese Financial Numerals",
            "kali": "Kayah Li Digits",
            "khmr": "Khmer Digits",
            "knda": "Kannada Digits",
            "lana": "Tai Tham Hora Digits",
            "lanatham": "Tai Tham Tham Digits",
            "laoo": "Lao Digits",
            "latn": "Western Digits",
            "lepc": "Lepcha Digits",
            "limb": "Limbu Digits"
          },
          "colCaseFirst": {
            "lower": "Sort Lowercase First"
          },
          "numbers": {
            "mlym": "Malayalam Digits",
            "mong": "Mongolian Digits",
            "mtei": "Meetei Mayek Digits",
            "mymr": "Myanmar Digits",
            "mymrshan": "Myanmar Shan Digits",
            "native": "Native Digits",
            "nkoo": "N’Ko Digits"
          },
          "colBackwards": {
            "no": "Sort Accents Normally"
          },
          "colCaseFirst": {
            "no": "Sort Normal Case Order"
          },
          "colCaseLevel": {
            "no": "Sort Case Insensitive"
          },
          "colHiraganaQuaternary": {
            "no": "Sort Kana Separately"
          },
          "colNormalization": {
            "no": "Sort Without Normalisation"
          },
          "colNumeric": {
            "no": "Sort Digits Individually"
          },
          "colAlternate": {
            "non-ignorable": "Sort Symbols"
          },
          "numbers": {
            "olck": "Ol Chiki Digits",
            "orya": "Oriya Digits",
            "osma": "Osmanya Digits"
          },
          "calendar": {
            "persian": "Persian Calendar"
          },
          "collation": {
            "phonebook": "Phonebook Sort Order",
            "phonetic": "Phonetic Sort Order",
            "pinyin": "Pinyin Sort Order"
          },
          "va": {
            "posix": "POSIX Compliant Locale"
          },
          "colStrength": {
            "primary": "Sort Base Letters Only",
            "quaternary": "Sort Accents/Case/Width/Kana"
          },
          "collation": {
            "reformed": "Reformed Sort Order"
          },
          "calendar": {
            "roc": "Minguo Calendar"
          },
          "numbers": {
            "roman": "Roman Numerals",
            "romanlow": "Roman Lowercase Numerals",
            "saur": "Saurashtra Digits"
          },
          "collation": {
            "search": "General-Purpose Search",
            "searchjl": "Search By Hangul Initial Consonant"
          },
          "colStrength": {
            "secondary": "Sort Accents"
          },
          "colAlternate": {
            "shifted": "Sort Ignoring Symbols"
          },
          "numbers": {
            "shrd": "Sharada Digits",
            "sora": "Sora Sompeng Digits"
          },
          "collation": {
            "standard": "Standard Sort Order",
            "stroke": "Stroke Sort Order"
          },
          "numbers": {
            "sund": "Sundanese Digits",
            "takr": "Takri Digits",
            "talu": "New Tai Lue Digits",
            "taml": "Traditional Tamil Numerals",
            "tamldec": "Tamil Digits",
            "telu": "Telugu Digits"
          },
          "colStrength": {
            "tertiary": "Sort Accents/Case/Width"
          },
          "numbers": {
            "thai": "Thai Digits",
            "tibt": "Tibetan Digits"
          },
          "collation": {
            "traditional": "Traditional Sort Order"
          },
          "numbers": {
            "traditional": "Traditional Numerals"
          },
          "collation": {
            "unihan": "Radical-Stroke Sort Order"
          },
          "colCaseFirst": {
            "upper": "Sort Uppercase First"
          },
          "numbers": {
            "vaii": "Vai Digits"
          },
          "colBackwards": {
            "yes": "Sort Accents Reversed"
          },
          "colCaseLevel": {
            "yes": "Sort Case Sensitive"
          },
          "colHiraganaQuaternary": {
            "yes": "Sort Kana Differently"
          },
          "colNormalization": {
            "yes": "Sort Unicode Normalised"
          },
          "colNumeric": {
            "yes": "Sort Digits Numerically"
          },
          "collation": {
            "zhuyin": "Zhuyin Sort Order"
          }
        },
        "codePatterns": {
          "language": "Language: {0}",
          "script": "Script: {0}",
          "territory": "Region: {0}"
        }
      }
    }
  }
}
)