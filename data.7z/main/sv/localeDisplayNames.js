Globalize.load({
  "main": {
    "sv": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "root"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0} ({1})",
          "localeSeparator": "{0}, {1}",
          "localeKeyTypePattern": "{0}: {1}"
        },
        "keys": {
          "calendar": "kalender",
          "colAlternate": "Ignorera symboler vid sortering",
          "colBackwards": "Sortera accenter omvänt",
          "colCaseFirst": "Ordna efter versaler/gemener",
          "colCaseLevel": "Skiftlägeskänslig sortering",
          "colHiraganaQuaternary": "Sortering efter kana",
          "colNormalization": "Normaliserad sortering",
          "colNumeric": "Numerisk sortering",
          "colStrength": "Sorteringsstyrka",
          "collation": "sorteringsordning",
          "currency": "valuta",
          "numbers": "siffror",
          "timezone": "Tidszon",
          "va": "Språkvariant",
          "variableTop": "Sortera som symboler",
          "x": "privat"
        },
        "types": {
          "numbers": {
            "arab": "indo-arabiska siffror",
            "arabext": "utökade indo-arabiska siffror",
            "armn": "armeniska taltecken",
            "armnlow": "små armeniska taltecken",
            "bali": "balinesiska siffror",
            "beng": "bengaliska siffror"
          },
          "collation": {
            "big5han": "big5-sorteringsordning"
          },
          "numbers": {
            "brah": "brahmiska siffror"
          },
          "calendar": {
            "buddhist": "buddistisk kalender"
          },
          "numbers": {
            "cakm": "chakma-siffror",
            "cham": "chamiska siffror"
          },
          "calendar": {
            "chinese": "kinesisk kalender",
            "coptic": "koptisk kalender",
            "dangi": "koreansk kalender"
          },
          "numbers": {
            "deva": "devanagariska siffror"
          },
          "collation": {
            "dictionary": "ordbokssorteringsordning",
            "ducet": "grundläggande Unicode-sorteringsordning",
            "eor": "sorteringsordning för flerspråkliga europeiska dokument"
          },
          "numbers": {
            "ethi": "etiopiska taltecken"
          },
          "calendar": {
            "ethiopic": "etiopisk kalender",
            "ethiopic-amete-alem": "etiopisk amete-alem-kalender"
          },
          "numbers": {
            "finance": "Finansiella siffror",
            "fullwide": "fullbreddssiffror"
          },
          "collation": {
            "gb2312han": "gb2312-sorteringsordning"
          },
          "numbers": {
            "geor": "georgiska taltecken"
          },
          "calendar": {
            "gregorian": "gregoriansk kalender"
          },
          "numbers": {
            "grek": "grekiska taltecken",
            "greklow": "små grekiska taltecken",
            "gujr": "gujaratiska siffror",
            "guru": "gurmukhiska siffror",
            "hanidec": "kinesiska decimaltal",
            "hans": "förenklat kinesiskt stavade tal",
            "hansfin": "förenklat kinesiskt finansiellt stavade tal",
            "hant": "traditionellt kinesiskt stavade tal",
            "hantfin": "traditionellt kinesiskt finansiellt stavade tal",
            "hebr": "hebreiska taltecken"
          },
          "calendar": {
            "hebrew": "hebreisk kalender"
          },
          "colStrength": {
            "identical": "Sortera alla"
          },
          "calendar": {
            "indian": "indisk kalender",
            "islamic": "islamisk kalender",
            "islamic-civil": "islamisk civil kalender",
            "islamic-rgsa": "islamisk kalender, Saudi-Arabien",
            "islamic-tbla": "islamisk kalender, astronomisk",
            "islamic-umalqura": "islamisk kalender, Umm al-Qura",
            "iso8601": "ISO 8601-kalender",
            "japanese": "japansk kalender"
          },
          "numbers": {
            "java": "javanesiska siffror",
            "jpan": "japanskt stavade tal",
            "jpanfin": "japanskt finansiellt stavade tal",
            "kali": "kayah li-siffror",
            "khmr": "khmeriska siffror",
            "knda": "kannadiska siffror",
            "lana": "tai tham hora-siffror",
            "lanatham": "tai tham tham-siffror",
            "laoo": "laotiska siffror",
            "latn": "västerländska siffror",
            "lepc": "lepcha-siffror",
            "limb": "limbu-siffror"
          },
          "colCaseFirst": {
            "lower": "Sortera gemener först"
          },
          "numbers": {
            "mlym": "malayalamiska siffror",
            "mong": "mongoliska siffror",
            "mtei": "meetei mayek-siffror",
            "mymr": "burmesiska siffror",
            "mymrshan": "burmesiska shan-siffror",
            "native": "Språkspecifika siffror",
            "nkoo": "n-kå-siffor"
          },
          "colBackwards": {
            "no": "sortera accenter normalt"
          },
          "colCaseFirst": {
            "no": "Ordna normalt efter skiftläge"
          },
          "colCaseLevel": {
            "no": "Sortera oavsett skiftläge"
          },
          "colHiraganaQuaternary": {
            "no": "Sortera kana separat"
          },
          "colNormalization": {
            "no": "sortera utan normalisering"
          },
          "colNumeric": {
            "no": "Sortera siffror för sig"
          },
          "colAlternate": {
            "non-ignorable": "sortera symboler"
          },
          "numbers": {
            "olck": "ol chiki-siffror",
            "orya": "oriyiska siffror",
            "osma": "osmanya-siffror"
          },
          "calendar": {
            "persian": "persisk kalender"
          },
          "collation": {
            "phonebook": "telefonkatalogssorteringsordning",
            "phonetic": "fonetisk sorteringsordning",
            "pinyin": "pinyin-sorteringsordning"
          },
          "colStrength": {
            "primary": "Sortera endast efter grundbokstäver",
            "quaternary": "Sortera efter accent/skiftläge/bredd/kana"
          },
          "collation": {
            "reformed": "reformerad sorteringsordning"
          },
          "calendar": {
            "roc": "kinesiska republikens kalender"
          },
          "numbers": {
            "roman": "romerska taltecken",
            "romanlow": "små romerska taltecken",
            "saur": "saurashtra-siffror"
          },
          "collation": {
            "search": "allmän sökning",
            "searchjl": "söksorteringsordning för att söka på inledande Hangul-konsonant"
          },
          "colStrength": {
            "secondary": "Sortera accenter"
          },
          "colAlternate": {
            "shifted": "Sortera oavsett symboler"
          },
          "numbers": {
            "shrd": "sharada-siffror",
            "sora": "sora sompeng-siffror"
          },
          "collation": {
            "standard": "normal sorteringsordning",
            "stroke": "strecksorteringsordning"
          },
          "numbers": {
            "sund": "sundanesiska siffror",
            "takr": "takri-siffror",
            "talu": "ny tai lü-siffror",
            "taml": "traditionella tamilska taltecken",
            "tamldec": "tamilska siffror",
            "telu": "telugiska siffror"
          },
          "colStrength": {
            "tertiary": "Sortera accenter/skiftläge/bredd"
          },
          "numbers": {
            "thai": "thailändska siffror",
            "tibt": "tibetanska siffror"
          },
          "collation": {
            "traditional": "traditionell ordning"
          },
          "numbers": {
            "traditional": "Traditionella siffror"
          },
          "collation": {
            "unihan": "radikal-streck-sorteringsordning"
          },
          "colCaseFirst": {
            "upper": "Sortera versaler först"
          },
          "numbers": {
            "vaii": "vai-siffror"
          },
          "colBackwards": {
            "yes": "sortera accenter omvänt"
          },
          "colCaseLevel": {
            "yes": "Sortera efter skiftläge"
          },
          "colHiraganaQuaternary": {
            "yes": "Sortera efter kana"
          },
          "colNormalization": {
            "yes": "sortera med Unicode-normalisering"
          },
          "colNumeric": {
            "yes": "Sortera siffror numeriskt"
          },
          "collation": {
            "zhuyin": "zhuyin-sorteringsordning"
          }
        },
        "codePatterns": {
          "language": "språk: {0}",
          "script": "skrift: {0}",
          "territory": "region: {0}"
        }
      }
    }
  }
}
)