Globalize.load({
  "main": {
    "nb": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "nb"
      },
      "localeDisplayNames": {
        "transformNames": {
          "BGN": "BGN",
          "Numeric": "Numerisk",
          "Tone": "Tonespråk",
          "UNGEGN": "UNGEGN",
          "x-Accents": "Aksenter",
          "x-Fullwidth": "Full bredde",
          "x-Halfwidth": "Halv bredde",
          "x-Jamo": "Jamo",
          "x-Pinyin": "Pinyin",
          "x-Publishing": "For publisering"
        }
      }
    }
  }
}
)