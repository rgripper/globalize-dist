Globalize.load({
  "main": {
    "nb": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "nb"
      },
      "localeDisplayNames": {
        "variants": {
          "1606NICT": "nyere mellomfransk til 1606",
          "1694ACAD": "eldre nyfransk",
          "1901": "tradisjonell tysk ortografi",
          "1959ACAD": "akademisk",
          "1994": "standardisert resisk ortografi",
          "1996": "tysk ortografi fra 1996",
          "ALALC97": "ALA-LC-romanisering, 1997-utgaven",
          "ALUKU": "Aluku-dialekt",
          "AREVELA": "øst-armensk",
          "AREVMDA": "vest-armensk",
          "BAKU1926": "samlet tyrkisk-latinsk alfabet",
          "BALANKA": "BALANKA",
          "BARLA": "BARLA",
          "BAUDDHA": "bauddha",
          "BISCAYAN": "biscayan",
          "BISKE": "san giorgio- og biladialekt",
          "BOHORIC": "bohorisk alfabet",
          "BOONT": "boontling",
          "DAJNKO": "dajnkoalfabet",
          "EKAVSK": "EKAVSK",
          "EMODENG": "tidlig moderne engelsk",
          "FONIPA": "det internasjonale fonetiske alfabet (IPA)",
          "FONUPA": "det uraliske fonetiske alfabet (UPA)",
          "FONXSAMP": "fonxsamp",
          "HEPBURN": "Hepburn-romanisering",
          "HOGNORSK": "høgnorsk",
          "IJEKAVSK": "IJEKAVSK",
          "ITIHASA": "itihasa",
          "JAUER": "jauer",
          "JYUTPING": "jyutping",
          "KKCOR": "felles ortografi",
          "KSCOR": "standard ortografi",
          "LAUKIKA": "laukika",
          "LIPAW": "resia med Lipovaz-dialekt",
          "LUNA1918": "LUNA1918",
          "METELKO": "Metelko-alfabet",
          "MONOTON": "monotonisk rettskriving",
          "NDYUKA": "Ndyuka-dialekt",
          "NEDIS": "natisonedialekt",
          "NJIVA": "gniva- og njivadialekt",
          "NULIK": "moderne volapük",
          "OSOJS": "oseacco- og osojanedialekt",
          "PAMAKA": "Pamaka-dialekt",
          "PETR1708": "PETR1708",
          "PINYIN": "pinyin",
          "POLYTON": "polytonisk rettskriving",
          "POSIX": "dataspråk",
          "PUTER": "PUTER",
          "REVISED": "revidert rettskriving",
          "RIGIK": "klassisk volapük",
          "ROZAJ": "resisk dialekt",
          "RUMGR": "RUMGR",
          "SAAHO": "saaho dialekt",
          "SCOTLAND": "skotsk standard engelsk",
          "SCOUSE": "scouse dialekt",
          "SOLBA": "stolvizza- og solbicadialekt",
          "SOTAV": "SOTAV",
          "SURMIRAN": "surmiransk",
          "SURSILV": "sursilvan",
          "SUTSILV": "sutsilvan",
          "TARASK": "taraskievica-ortografi",
          "UCCOR": "UCCOR",
          "UCRCOR": "felles revidert ortografi",
          "ULSTER": "ulster",
          "UNIFON": "UNIFON",
          "VAIDIKA": "vaidika",
          "VALENCIA": "valensisk dialekt",
          "VALLADER": "vallader",
          "WADEGILE": "Wade-Giles"
        }
      }
    }
  }
}
)