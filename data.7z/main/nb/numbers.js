Globalize.load({
  "main": {
    "nb": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "nb"
      },
      "numbers": {
        "defaultNumberingSystem": "latn",
        "otherNumberingSystems": {
          "native": "latn"
        },
        "minimumGroupingDigits": "1",
        "symbols-numberSystem-latn": {
          "decimal": ",",
          "group": " ",
          "list": ";",
          "percentSign": "%",
          "plusSign": "+",
          "minusSign": "−",
          "exponential": "E",
          "superscriptingExponent": "×",
          "perMille": "‰",
          "infinity": "∞",
          "nan": "NaN",
          "timeSeparator": "."
        },
        "decimalFormats-numberSystem-latn": {
          "standard": "#,##0.###",
          "long": {
            "decimalFormat": {
              "1000-count-one": "0 tusen",
              "1000-count-other": "0 tusen",
              "10000-count-one": "00 tusen",
              "10000-count-other": "00 tusen",
              "100000-count-one": "000 tusen",
              "100000-count-other": "000 tusen",
              "1000000-count-one": "0 million",
              "1000000-count-other": "0 millioner",
              "10000000-count-one": "00 million",
              "10000000-count-other": "00 millioner",
              "100000000-count-one": "000 million",
              "100000000-count-other": "000 millioner",
              "1000000000-count-one": "0 milliard",
              "1000000000-count-other": "0 milliarder",
              "10000000000-count-one": "00 milliard",
              "10000000000-count-other": "00 milliarder",
              "100000000000-count-one": "000 milliard",
              "100000000000-count-other": "000 milliarder",
              "1000000000000-count-one": "0 billion",
              "1000000000000-count-other": "0 billioner",
              "10000000000000-count-one": "00 billioner",
              "10000000000000-count-other": "00 billioner",
              "100000000000000-count-one": "000 billioner",
              "100000000000000-count-other": "000 billioner"
            }
          },
          "short": {
            "decimalFormat": {
              "1000-count-one": "0 K",
              "1000-count-other": "0 K",
              "10000-count-one": "00 K",
              "10000-count-other": "00 K",
              "100000-count-one": "000 K",
              "100000-count-other": "000 K",
              "1000000-count-one": "0 mill",
              "1000000-count-other": "0 mill",
              "10000000-count-one": "00 mill",
              "10000000-count-other": "00 mill",
              "100000000-count-one": "000 mill",
              "100000000-count-other": "000 mill",
              "1000000000-count-one": "0 mrd",
              "1000000000-count-other": "0 mrd",
              "10000000000-count-one": "00 mrd",
              "10000000000-count-other": "00 mrd",
              "100000000000-count-one": "000 mrd",
              "100000000000-count-other": "000 mrd",
              "1000000000000-count-one": "0 bill",
              "1000000000000-count-other": "0 bill",
              "10000000000000-count-one": "00 bill",
              "10000000000000-count-other": "00 bill",
              "100000000000000-count-one": "000 bill",
              "100000000000000-count-other": "000 bill"
            }
          }
        },
        "scientificFormats-numberSystem-latn": {
          "standard": "#E0"
        },
        "percentFormats-numberSystem-latn": {
          "standard": "#,##0 %"
        },
        "currencyFormats-numberSystem-latn": {
          "currencySpacing": {
            "beforeCurrency": {
              "currencyMatch": "[:^S:]",
              "surroundingMatch": "[:digit:]",
              "insertBetween": " "
            },
            "afterCurrency": {
              "currencyMatch": "[:^S:]",
              "surroundingMatch": "[:digit:]",
              "insertBetween": " "
            }
          },
          "accounting": "¤ #,##0.00",
          "standard": "¤ #,##0.00",
          "unitPattern-count-one": "{0} {1}",
          "unitPattern-count-other": "{0} {1}"
        },
        "miscPatterns-numberSystem-latn": {
          "atLeast": "⩾{0}",
          "range": "{0}‒{1}"
        }
      }
    }
  }
}
)