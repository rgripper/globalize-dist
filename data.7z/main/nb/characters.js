Globalize.load({
  "main": {
    "nb": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "nb"
      },
      "characters": {
        "exemplarCharacters": "[a à b c d e é f g h i j k l m n o ó ò ô p q r s t u v w x y z æ ø å]",
        "auxiliary": "[á ǎ ã č ç đ è ê í ń ñ ŋ š ŧ ü ž ä ö]",
        "punctuation": "[\\- – , ; \\: ! ? . ' \" « » ( ) \\[ \\] \\{ \\} § @ * / \\\\]",
        "index": "[A B C D E F G H I J K L M N O P Q R S T U V W X Y Z Æ Ø Å]",
        "ellipsis": {
          "initial": "…{0}",
          "medial": "{0}…{1}",
          "final": "{0}…",
          "word-initial": "… {0}",
          "word-medial": "{0} … {1}",
          "word-final": "{0} …"
        },
        "moreInformation": "?"
      }
    }
  }
}
)