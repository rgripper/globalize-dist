Globalize.load({
  "main": {
    "zh-Hant": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10895 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-01 13:57:54 -0500 (Mon, 01 Sep 2014) $"
        },
        "language": "root",
        "script": "Hant"
      },
      "listPatterns": {
        "listPattern-type-standard": {
          "start": "{0}、{1}",
          "middle": "{0}、{1}",
          "end": "{0}和{1}",
          "2": "{0}和{1}"
        },
        "listPattern-type-unit": {
          "start": "{0}{1}",
          "middle": "{0}{1}",
          "end": "{0}{1}",
          "2": "{0}{1}"
        },
        "listPattern-type-unit-narrow": {
          "start": "{0}{1}",
          "middle": "{0}{1}",
          "end": "{0}{1}",
          "2": "{0}{1}"
        },
        "listPattern-type-unit-short": {
          "start": "{0}{1}",
          "middle": "{0}{1}",
          "end": "{0}{1}",
          "2": "{0}{1}"
        }
      }
    }
  }
}
)