Globalize.load({
  "main": {
    "zh-Hant": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10895 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-01 13:57:54 -0500 (Mon, 01 Sep 2014) $"
        },
        "language": "root",
        "script": "Hant"
      },
      "localeDisplayNames": {
        "transformNames": {
          "BGN": "美國地名委員會",
          "Numeric": "數字",
          "Tone": "聲調",
          "UNGEGN": "聯合國地名專家組",
          "x-Accents": "變音符號",
          "x-Fullwidth": "全形",
          "x-Halfwidth": "半形",
          "x-Jamo": "韓文字母",
          "x-Pinyin": "拼音",
          "x-Publishing": "出版"
        }
      }
    }
  }
}
)