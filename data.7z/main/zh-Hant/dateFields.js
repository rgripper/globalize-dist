Globalize.load({
  "main": {
    "zh-Hant": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10895 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-01 13:57:54 -0500 (Mon, 01 Sep 2014) $"
        },
        "language": "root",
        "script": "Hant"
      },
      "dates": {
        "fields": {
          "era": {
            "displayName": "年代"
          },
          "year": {
            "displayName": "年",
            "relative-type--1": "去年",
            "relative-type-0": "今年",
            "relative-type-1": "明年",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 年後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 年前"
            }
          },
          "year-short": {
            "displayName": "年",
            "relative-type--1": "去年",
            "relative-type-0": "今年",
            "relative-type-1": "明年",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 年後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 年前"
            }
          },
          "year-narrow": {
            "displayName": "年",
            "relative-type--1": "去年",
            "relative-type-0": "今年",
            "relative-type-1": "明年",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 年後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 年前"
            }
          },
          "quarter": {
            "displayName": "季",
            "relative-type--1": "last quarter",
            "relative-type-0": "this quarter",
            "relative-type-1": "next quarter",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 季後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 季前"
            }
          },
          "quarter-short": {
            "displayName": "季",
            "relative-type--1": "last quarter",
            "relative-type-0": "this quarter",
            "relative-type-1": "next quarter",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 季後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 季前"
            }
          },
          "quarter-narrow": {
            "displayName": "季",
            "relative-type--1": "last quarter",
            "relative-type-0": "this quarter",
            "relative-type-1": "next quarter",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 季後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 季前"
            }
          },
          "month": {
            "displayName": "月",
            "relative-type--1": "上個月",
            "relative-type-0": "本月",
            "relative-type-1": "下個月",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 個月後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 個月前"
            }
          },
          "month-short": {
            "displayName": "月",
            "relative-type--1": "上個月",
            "relative-type-0": "本月",
            "relative-type-1": "下個月",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 個月後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 個月前"
            }
          },
          "month-narrow": {
            "displayName": "月",
            "relative-type--1": "上個月",
            "relative-type-0": "本月",
            "relative-type-1": "下個月",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 個月後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 個月前"
            }
          },
          "week": {
            "displayName": "週",
            "relative-type--1": "上週",
            "relative-type-0": "本週",
            "relative-type-1": "下週",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 週後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 週前"
            }
          },
          "week-short": {
            "displayName": "週",
            "relative-type--1": "上週",
            "relative-type-0": "本週",
            "relative-type-1": "下週",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 週後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 週前"
            }
          },
          "week-narrow": {
            "displayName": "週",
            "relative-type--1": "上週",
            "relative-type-0": "本週",
            "relative-type-1": "下週",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 週後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 週前"
            }
          },
          "day": {
            "displayName": "日",
            "relative-type--1": "昨天",
            "relative-type--2": "前天",
            "relative-type-0": "今天",
            "relative-type-1": "明天",
            "relative-type-2": "後天",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 天後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 天前"
            }
          },
          "day-short": {
            "displayName": "日",
            "relative-type--1": "昨天",
            "relative-type--2": "前天",
            "relative-type-0": "今天",
            "relative-type-1": "明天",
            "relative-type-2": "後天",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 天後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 天前"
            }
          },
          "day-narrow": {
            "displayName": "日",
            "relative-type--1": "昨天",
            "relative-type--2": "前天",
            "relative-type-0": "今天",
            "relative-type-1": "明天",
            "relative-type-2": "後天",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 天後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 天前"
            }
          },
          "weekday": {
            "displayName": "週天"
          },
          "sun": {
            "relative-type--1": "上週日",
            "relative-type-0": "本週日",
            "relative-type-1": "下週日"
          },
          "sun-short": {
            "relative-type--1": "上週日",
            "relative-type-0": "本週日",
            "relative-type-1": "下週日"
          },
          "sun-narrow": {
            "relative-type--1": "上週日",
            "relative-type-0": "本週日",
            "relative-type-1": "下週日"
          },
          "mon": {
            "relative-type--1": "上週一",
            "relative-type-0": "本週一",
            "relative-type-1": "下週一"
          },
          "mon-short": {
            "relative-type--1": "上週一",
            "relative-type-0": "本週一",
            "relative-type-1": "下週一"
          },
          "mon-narrow": {
            "relative-type--1": "上週一",
            "relative-type-0": "本週一",
            "relative-type-1": "下週一"
          },
          "tue": {
            "relative-type--1": "上週二",
            "relative-type-0": "本週二",
            "relative-type-1": "下週二"
          },
          "tue-short": {
            "relative-type--1": "上週二",
            "relative-type-0": "本週二",
            "relative-type-1": "下週二"
          },
          "tue-narrow": {
            "relative-type--1": "上週二",
            "relative-type-0": "本週二",
            "relative-type-1": "下週二"
          },
          "wed": {
            "relative-type--1": "上週三",
            "relative-type-0": "本週三",
            "relative-type-1": "下週三"
          },
          "wed-short": {
            "relative-type--1": "上週三",
            "relative-type-0": "本週三",
            "relative-type-1": "下週三"
          },
          "wed-narrow": {
            "relative-type--1": "上週三",
            "relative-type-0": "本週三",
            "relative-type-1": "下週三"
          },
          "thu": {
            "relative-type--1": "上週四",
            "relative-type-0": "本週四",
            "relative-type-1": "下週四"
          },
          "thu-short": {
            "relative-type--1": "上週四",
            "relative-type-0": "本週四",
            "relative-type-1": "下週四"
          },
          "thu-narrow": {
            "relative-type--1": "上週四",
            "relative-type-0": "本週四",
            "relative-type-1": "下週四"
          },
          "fri": {
            "relative-type--1": "上週五",
            "relative-type-0": "本週五",
            "relative-type-1": "下週五"
          },
          "fri-short": {
            "relative-type--1": "上週五",
            "relative-type-0": "本週五",
            "relative-type-1": "下週五"
          },
          "fri-narrow": {
            "relative-type--1": "上週五",
            "relative-type-0": "本週五",
            "relative-type-1": "下週五"
          },
          "sat": {
            "relative-type--1": "上週六",
            "relative-type-0": "本週六",
            "relative-type-1": "下週六"
          },
          "sat-short": {
            "relative-type--1": "上週六",
            "relative-type-0": "本週六",
            "relative-type-1": "下週六"
          },
          "sat-narrow": {
            "relative-type--1": "上週六",
            "relative-type-0": "本週六",
            "relative-type-1": "下週六"
          },
          "dayperiod": {
            "displayName": "上午/下午"
          },
          "hour": {
            "displayName": "小時",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 小時後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 小時前"
            }
          },
          "hour-short": {
            "displayName": "小時",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 小時後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 小時前"
            }
          },
          "hour-narrow": {
            "displayName": "小時",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 小時後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 小時前"
            }
          },
          "minute": {
            "displayName": "分鐘",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 分鐘後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 分鐘前"
            }
          },
          "minute-short": {
            "displayName": "分鐘",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 分鐘後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 分鐘前"
            }
          },
          "minute-narrow": {
            "displayName": "分鐘",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 分鐘後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 分鐘前"
            }
          },
          "second": {
            "displayName": "秒",
            "relative-type-0": "現在",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 秒後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 秒前"
            }
          },
          "second-short": {
            "displayName": "秒",
            "relative-type-0": "現在",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 秒後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 秒前"
            }
          },
          "second-narrow": {
            "displayName": "秒",
            "relative-type-0": "現在",
            "relativeTime-type-future": {
              "relativeTimePattern-count-other": "{0} 秒後"
            },
            "relativeTime-type-past": {
              "relativeTimePattern-count-other": "{0} 秒前"
            }
          },
          "zone": {
            "displayName": "時區"
          }
        }
      }
    }
  }
}
)