Globalize.load({
  "main": {
    "zh-Hant": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10895 $"
        },
        "generation": {
          "_date": "$Date: 2014-09-01 13:57:54 -0500 (Mon, 01 Sep 2014) $"
        },
        "language": "root",
        "script": "Hant"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0}（{1}）",
          "localeSeparator": "{0}，{1}",
          "localeKeyTypePattern": "{0}：{1}"
        },
        "keys": {
          "calendar": "曆法",
          "colAlternate": "略過符號排序",
          "colBackwards": "反向重音排序",
          "colCaseFirst": "大寫/小寫排列",
          "colCaseLevel": "區分大小寫排序",
          "colHiraganaQuaternary": "假名排序",
          "colNormalization": "正規化排序",
          "colNumeric": "數字排序",
          "colStrength": "排序強度",
          "collation": "排序",
          "currency": "貨幣",
          "numbers": "數字",
          "timezone": "時區",
          "va": "區域變異",
          "variableTop": "以符號排序",
          "x": "私人使用"
        },
        "types": {
          "numbers": {
            "arab": "阿拉伯-印度數字",
            "arabext": "阿拉伯-印度擴充數字",
            "armn": "亞美尼亞數字",
            "armnlow": "小寫亞美尼亞數字",
            "bali": "峇里文數字",
            "beng": "孟加拉數字"
          },
          "collation": {
            "big5han": "繁體中文排序 - Big5"
          },
          "numbers": {
            "brah": "婆羅米數字"
          },
          "calendar": {
            "buddhist": "佛曆"
          },
          "numbers": {
            "cakm": "查克馬數字",
            "cham": "占文數字"
          },
          "calendar": {
            "chinese": "農曆",
            "coptic": "科普特曆",
            "dangi": "檀紀曆"
          },
          "numbers": {
            "deva": "梵文數字"
          },
          "collation": {
            "dictionary": "字典排序",
            "ducet": "預設 Unicode 排序",
            "eor": "歐洲排序規則"
          },
          "numbers": {
            "ethi": "衣索比亞數字"
          },
          "calendar": {
            "ethiopic": "衣索比亞曆",
            "ethiopic-amete-alem": "衣索比亞曆 (Amete Alem)"
          },
          "numbers": {
            "finance": "金融數字",
            "fullwide": "全形數字"
          },
          "collation": {
            "gb2312han": "簡體中文排序 - GB2312"
          },
          "numbers": {
            "geor": "喬治亞數字"
          },
          "calendar": {
            "gregorian": "公曆"
          },
          "numbers": {
            "grek": "希臘數字",
            "greklow": "小寫希臘數字",
            "gujr": "古吉拉特數字",
            "guru": "古爾穆奇數字",
            "hanidec": "中文十進位數字",
            "hans": "小寫簡體中文數字",
            "hansfin": "大寫簡體中文數字",
            "hant": "小寫繁體中文數字",
            "hantfin": "大寫繁體中文數字",
            "hebr": "希伯來數字"
          },
          "calendar": {
            "hebrew": "希伯來曆"
          },
          "colStrength": {
            "identical": "全部排序"
          },
          "calendar": {
            "indian": "印度國曆",
            "islamic": "伊斯蘭曆",
            "islamic-civil": "伊斯蘭民用曆",
            "islamic-rgsa": "伊斯蘭新月曆",
            "islamic-tbla": "伊斯蘭天文曆",
            "islamic-umalqura": "烏姆庫拉曆",
            "iso8601": "國際標準 ISO 8601",
            "japanese": "日本曆"
          },
          "numbers": {
            "java": "爪哇文數字",
            "jpan": "小寫日文數字",
            "jpanfin": "大寫日文數字",
            "kali": "克耶數字",
            "khmr": "高棉數字",
            "knda": "坎那達數字",
            "lana": "老傣文數字",
            "lanatham": "蘭納文數字",
            "laoo": "寮國數字",
            "latn": "阿拉伯數字",
            "lepc": "西納文數字",
            "limb": "林布文數字"
          },
          "colCaseFirst": {
            "lower": "優先排序小寫"
          },
          "numbers": {
            "mlym": "馬來亞拉姆數字",
            "mong": "蒙古數字",
            "mtei": "曼尼普爾數字",
            "mymr": "緬甸數字",
            "mymrshan": "緬甸撣文數字",
            "native": "原始數字",
            "nkoo": "曼德數字"
          },
          "colBackwards": {
            "no": "正常排序重音"
          },
          "colCaseFirst": {
            "no": "正常大小寫順序排序"
          },
          "colCaseLevel": {
            "no": "不分大小寫排序"
          },
          "colHiraganaQuaternary": {
            "no": "個別排序假名"
          },
          "colNormalization": {
            "no": "非正規化排序"
          },
          "colNumeric": {
            "no": "個別排序數字"
          },
          "colAlternate": {
            "non-ignorable": "排序符號"
          },
          "numbers": {
            "olck": "桑塔利文數字",
            "orya": "歐利亞數字",
            "osma": "奧斯曼亞數字"
          },
          "calendar": {
            "persian": "波斯曆"
          },
          "collation": {
            "phonebook": "電話簿排序",
            "phonetic": "發音排序",
            "pinyin": "拼音排序"
          },
          "colStrength": {
            "primary": "僅排序基礎字母",
            "quaternary": "排序重音/大小寫/全半形/假名"
          },
          "collation": {
            "reformed": "改良排序"
          },
          "calendar": {
            "roc": "民國曆"
          },
          "numbers": {
            "roman": "羅馬數字",
            "romanlow": "小寫羅馬數字",
            "saur": "索拉什特拉文數字"
          },
          "collation": {
            "search": "一般用途搜尋",
            "searchjl": "韓文子音排序"
          },
          "colStrength": {
            "secondary": "排序重音"
          },
          "colAlternate": {
            "shifted": "略過符號排序"
          },
          "numbers": {
            "shrd": "夏拉達數字",
            "sora": "索朗桑朋數字"
          },
          "collation": {
            "standard": "標準排序",
            "stroke": "筆畫排序"
          },
          "numbers": {
            "sund": "巽他數字",
            "takr": "塔卡里數字",
            "talu": "新傣仂文數字",
            "taml": "坦米爾數字",
            "tamldec": "坦米爾數字",
            "telu": "泰盧固數字"
          },
          "colStrength": {
            "tertiary": "排序重音/大小寫/全半形"
          },
          "numbers": {
            "thai": "泰文數字",
            "tibt": "西藏數字"
          },
          "collation": {
            "traditional": "傳統排序"
          },
          "numbers": {
            "traditional": "傳統數字"
          },
          "collation": {
            "unihan": "部首筆畫排序"
          },
          "colCaseFirst": {
            "upper": "優先排序大寫"
          },
          "numbers": {
            "vaii": "瓦伊文數字"
          },
          "colBackwards": {
            "yes": "依反向重音排序"
          },
          "colCaseLevel": {
            "yes": "依大小寫排序"
          },
          "colHiraganaQuaternary": {
            "yes": "分別排序假名"
          },
          "colNormalization": {
            "yes": "依正規化排序 Unicode"
          },
          "colNumeric": {
            "yes": "依數字順序排序數字"
          },
          "collation": {
            "zhuyin": "注音排序"
          }
        },
        "codePatterns": {
          "language": "語言：{0}",
          "script": "文字：{0}",
          "territory": "地區：{0}"
        }
      }
    }
  }
}
)