Globalize.load({
  "main": {
    "root": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10712 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-01 12:07:43 -0500 (Fri, 01 Aug 2014) $"
        },
        "language": "root"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0} ({1})",
          "localeSeparator": "{0}, {1}",
          "localeKeyTypePattern": "{0}: {1}"
        },
        "keys": {
          "calendar": "calendar",
          "collation": "collation",
          "currency": "currency",
          "numbers": "numbers"
        },
        "types": {
          "numbers": {
            "arab": "arab",
            "arabext": "arabext",
            "armn": "armn",
            "armnlow": "armnlow",
            "bali": "bali",
            "beng": "beng"
          },
          "collation": {
            "big5han": "big5han"
          },
          "numbers": {
            "brah": "brah"
          },
          "calendar": {
            "buddhist": "buddhist"
          },
          "numbers": {
            "cakm": "cakm",
            "cham": "cham"
          },
          "calendar": {
            "chinese": "chinese",
            "coptic": "coptic",
            "dangi": "dangi"
          },
          "numbers": {
            "deva": "deva"
          },
          "collation": {
            "dictionary": "dictionary",
            "ducet": "ducet",
            "eor": "eor"
          },
          "numbers": {
            "ethi": "ethi"
          },
          "calendar": {
            "ethiopic": "ethiopic",
            "ethiopic-amete-alem": "ethiopic-amete-alem"
          },
          "numbers": {
            "fullwide": "fullwide"
          },
          "collation": {
            "gb2312han": "gb2312han"
          },
          "numbers": {
            "geor": "geor"
          },
          "calendar": {
            "gregorian": "gregorian"
          },
          "numbers": {
            "grek": "grek",
            "greklow": "greklow",
            "gujr": "gujr",
            "guru": "guru",
            "hanidec": "hanidec",
            "hans": "hans",
            "hansfin": "hansfin",
            "hant": "hant",
            "hantfin": "hantfin",
            "hebr": "hebr"
          },
          "calendar": {
            "hebrew": "hebrew",
            "indian": "indian",
            "islamic": "islamic",
            "islamic-civil": "islamic-civil",
            "islamic-rgsa": "islamic-rgsa",
            "islamic-tbla": "islamic-tbla",
            "islamic-umalqura": "islamic-umalqura",
            "iso8601": "iso8601",
            "japanese": "japanese"
          },
          "numbers": {
            "java": "java",
            "jpan": "jpan",
            "jpanfin": "jpanfin",
            "kali": "kali",
            "khmr": "khmr",
            "knda": "knda",
            "lana": "lana",
            "lanatham": "lanatham",
            "laoo": "laoo",
            "latn": "latn",
            "lepc": "lepc",
            "limb": "limb",
            "mlym": "mlym",
            "mong": "mong",
            "mtei": "mtei",
            "mymr": "mymr",
            "mymrshan": "mymrshan",
            "nkoo": "nkoo",
            "olck": "olck",
            "orya": "orya",
            "osma": "osma"
          },
          "calendar": {
            "persian": "persian"
          },
          "collation": {
            "phonebook": "phonebook",
            "pinyin": "pinyin",
            "reformed": "reformed"
          },
          "calendar": {
            "roc": "roc"
          },
          "numbers": {
            "roman": "roman",
            "romanlow": "romanlow",
            "saur": "saur"
          },
          "collation": {
            "search": "search",
            "searchjl": "searchjl"
          },
          "numbers": {
            "shrd": "shrd",
            "sora": "sora"
          },
          "collation": {
            "standard": "standard",
            "stroke": "stroke"
          },
          "numbers": {
            "sund": "sund",
            "takr": "takr",
            "talu": "talu",
            "taml": "taml",
            "tamldec": "tamldec",
            "telu": "telu",
            "thai": "thai",
            "tibt": "tibt"
          },
          "collation": {
            "traditional": "traditional",
            "unihan": "unihan"
          },
          "numbers": {
            "vaii": "vaii"
          },
          "collation": {
            "zhuyin": "zhuyin"
          }
        },
        "codePatterns": {
          "language": "{0}",
          "script": "{0}",
          "territory": "{0}"
        }
      }
    }
  }
}
)