Globalize.load({
  "main": {
    "root": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10712 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-01 12:07:43 -0500 (Fri, 01 Aug 2014) $"
        },
        "language": "root"
      },
      "numbers": {
        "defaultNumberingSystem": "latn",
        "otherNumberingSystems": {
          "native": "latn"
        },
        "minimumGroupingDigits": "1",
        "symbols-numberSystem-latn": {
          "decimal": ".",
          "group": ",",
          "list": ";",
          "percentSign": "%",
          "plusSign": "+",
          "minusSign": "-",
          "exponential": "E",
          "superscriptingExponent": "×",
          "perMille": "‰",
          "infinity": "∞",
          "nan": "NaN",
          "timeSeparator": ":"
        },
        "decimalFormats-numberSystem-latn": {
          "standard": "#,##0.###",
          "long": {
            "decimalFormat": {
              "1000-count-other": "0K",
              "10000-count-other": "00K",
              "100000-count-other": "000K",
              "1000000-count-other": "0M",
              "10000000-count-other": "00M",
              "100000000-count-other": "000M",
              "1000000000-count-other": "0G",
              "10000000000-count-other": "00G",
              "100000000000-count-other": "000G",
              "1000000000000-count-other": "0T",
              "10000000000000-count-other": "00T",
              "100000000000000-count-other": "000T"
            }
          },
          "short": {
            "decimalFormat": {
              "1000-count-other": "0K",
              "10000-count-other": "00K",
              "100000-count-other": "000K",
              "1000000-count-other": "0M",
              "10000000-count-other": "00M",
              "100000000-count-other": "000M",
              "1000000000-count-other": "0G",
              "10000000000-count-other": "00G",
              "100000000000-count-other": "000G",
              "1000000000000-count-other": "0T",
              "10000000000000-count-other": "00T",
              "100000000000000-count-other": "000T"
            }
          }
        },
        "scientificFormats-numberSystem-latn": {
          "standard": "#E0"
        },
        "percentFormats-numberSystem-latn": {
          "standard": "#,##0%"
        },
        "currencyFormats-numberSystem-latn": {
          "currencySpacing": {
            "beforeCurrency": {
              "currencyMatch": "[:^S:]",
              "surroundingMatch": "[:digit:]",
              "insertBetween": " "
            },
            "afterCurrency": {
              "currencyMatch": "[:^S:]",
              "surroundingMatch": "[:digit:]",
              "insertBetween": " "
            }
          },
          "accounting": "¤ #,##0.00",
          "standard": "¤ #,##0.00",
          "unitPattern-count-other": "{0} {1}"
        },
        "miscPatterns-numberSystem-latn": {
          "atLeast": "⩾{0}",
          "range": "{0}–{1}"
        }
      }
    }
  }
}
)