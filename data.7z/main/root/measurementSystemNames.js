Globalize.load({
  "main": {
    "root": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10712 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-01 12:07:43 -0500 (Fri, 01 Aug 2014) $"
        },
        "language": "root"
      },
      "localeDisplayNames": {
        "measurementSystemNames": {
          "US": "US",
          "metric": "Metric",
          "UK": "UK"
        }
      }
    }
  }
}
)