Globalize.load({
  "main": {
    "en": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10887 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-31 14:23:52 -0500 (Sun, 31 Aug 2014) $"
        },
        "language": "en"
      },
      "listPatterns": {
        "listPattern-type-standard": {
          "start": "{0}, {1}",
          "middle": "{0}, {1}",
          "end": "{0}, and {1}",
          "2": "{0} and {1}"
        },
        "listPattern-type-unit": {
          "start": "{0}, {1}",
          "middle": "{0}, {1}",
          "end": "{0}, {1}",
          "2": "{0}, {1}"
        },
        "listPattern-type-unit-narrow": {
          "start": "{0} {1}",
          "middle": "{0} {1}",
          "end": "{0} {1}",
          "2": "{0} {1}"
        },
        "listPattern-type-unit-short": {
          "start": "{0}, {1}",
          "middle": "{0}, {1}",
          "end": "{0}, {1}",
          "2": "{0}, {1}"
        }
      }
    }
  }
}
)