Globalize.load({
  "main": {
    "en": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10887 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-31 14:23:52 -0500 (Sun, 31 Aug 2014) $"
        },
        "language": "en"
      },
      "characters": {
        "exemplarCharacters": "[a b c d e f g h i j k l m n o p q r s t u v w x y z]",
        "auxiliary": "[á à ă â å ä ã ā æ ç é è ĕ ê ë ē í ì ĭ î ï ī ñ ó ò ŏ ô ö ø ō œ ú ù ŭ û ü ū ÿ]",
        "punctuation": "[\\- ‐ – — , ; \\: ! ? . … ' ‘ ’ \" “ ” ( ) \\[ \\] § @ * / \\& # † ‡ ′ ″]",
        "index": "[A B C D E F G H I J K L M N O P Q R S T U V W X Y Z]",
        "ellipsis": {
          "initial": "…{0}",
          "medial": "{0}…{1}",
          "final": "{0}…",
          "word-initial": "… {0}",
          "word-medial": "{0} … {1}",
          "word-final": "{0} …"
        },
        "moreInformation": "?"
      }
    }
  }
}
)