Globalize.load({
  "main": {
    "en": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10887 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-31 14:23:52 -0500 (Sun, 31 Aug 2014) $"
        },
        "language": "en"
      },
      "dates": {
        "calendars": {
          "ethiopic-amete-alem": {
            "months": {
              "format": {
                "abbreviated": {
                  "1": "Meskerem",
                  "2": "Tekemt",
                  "3": "Hedar",
                  "4": "Tahsas",
                  "5": "Ter",
                  "6": "Yekatit",
                  "7": "Megabit",
                  "8": "Miazia",
                  "9": "Genbot",
                  "10": "Sene",
                  "11": "Hamle",
                  "12": "Nehasse",
                  "13": "Pagumen"
                },
                "narrow": {
                  "1": "1",
                  "2": "2",
                  "3": "3",
                  "4": "4",
                  "5": "5",
                  "6": "6",
                  "7": "7",
                  "8": "8",
                  "9": "9",
                  "10": "10",
                  "11": "11",
                  "12": "12",
                  "13": "13"
                },
                "wide": {
                  "1": "Meskerem",
                  "2": "Tekemt",
                  "3": "Hedar",
                  "4": "Tahsas",
                  "5": "Ter",
                  "6": "Yekatit",
                  "7": "Megabit",
                  "8": "Miazia",
                  "9": "Genbot",
                  "10": "Sene",
                  "11": "Hamle",
                  "12": "Nehasse",
                  "13": "Pagumen"
                }
              },
              "stand-alone": {
                "abbreviated": {
                  "1": "Meskerem",
                  "2": "Tekemt",
                  "3": "Hedar",
                  "4": "Tahsas",
                  "5": "Ter",
                  "6": "Yekatit",
                  "7": "Megabit",
                  "8": "Miazia",
                  "9": "Genbot",
                  "10": "Sene",
                  "11": "Hamle",
                  "12": "Nehasse",
                  "13": "Pagumen"
                },
                "narrow": {
                  "1": "1",
                  "2": "2",
                  "3": "3",
                  "4": "4",
                  "5": "5",
                  "6": "6",
                  "7": "7",
                  "8": "8",
                  "9": "9",
                  "10": "10",
                  "11": "11",
                  "12": "12",
                  "13": "13"
                },
                "wide": {
                  "1": "Meskerem",
                  "2": "Tekemt",
                  "3": "Hedar",
                  "4": "Tahsas",
                  "5": "Ter",
                  "6": "Yekatit",
                  "7": "Megabit",
                  "8": "Miazia",
                  "9": "Genbot",
                  "10": "Sene",
                  "11": "Hamle",
                  "12": "Nehasse",
                  "13": "Pagumen"
                }
              }
            },
            "days": {
              "format": {
                "abbreviated": {
                  "sun": "Sun",
                  "mon": "Mon",
                  "tue": "Tue",
                  "wed": "Wed",
                  "thu": "Thu",
                  "fri": "Fri",
                  "sat": "Sat"
                },
                "narrow": {
                  "sun": "S",
                  "mon": "M",
                  "tue": "T",
                  "wed": "W",
                  "thu": "T",
                  "fri": "F",
                  "sat": "S"
                },
                "short": {
                  "sun": "Su",
                  "mon": "Mo",
                  "tue": "Tu",
                  "wed": "We",
                  "thu": "Th",
                  "fri": "Fr",
                  "sat": "Sa"
                },
                "wide": {
                  "sun": "Sunday",
                  "mon": "Monday",
                  "tue": "Tuesday",
                  "wed": "Wednesday",
                  "thu": "Thursday",
                  "fri": "Friday",
                  "sat": "Saturday"
                }
              },
              "stand-alone": {
                "abbreviated": {
                  "sun": "Sun",
                  "mon": "Mon",
                  "tue": "Tue",
                  "wed": "Wed",
                  "thu": "Thu",
                  "fri": "Fri",
                  "sat": "Sat"
                },
                "narrow": {
                  "sun": "S",
                  "mon": "M",
                  "tue": "T",
                  "wed": "W",
                  "thu": "T",
                  "fri": "F",
                  "sat": "S"
                },
                "short": {
                  "sun": "Su",
                  "mon": "Mo",
                  "tue": "Tu",
                  "wed": "We",
                  "thu": "Th",
                  "fri": "Fr",
                  "sat": "Sa"
                },
                "wide": {
                  "sun": "Sunday",
                  "mon": "Monday",
                  "tue": "Tuesday",
                  "wed": "Wednesday",
                  "thu": "Thursday",
                  "fri": "Friday",
                  "sat": "Saturday"
                }
              }
            },
            "quarters": {
              "format": {
                "abbreviated": {
                  "1": "Q1",
                  "2": "Q2",
                  "3": "Q3",
                  "4": "Q4"
                },
                "narrow": {
                  "1": "1",
                  "2": "2",
                  "3": "3",
                  "4": "4"
                },
                "wide": {
                  "1": "1st quarter",
                  "2": "2nd quarter",
                  "3": "3rd quarter",
                  "4": "4th quarter"
                }
              },
              "stand-alone": {
                "abbreviated": {
                  "1": "Q1",
                  "2": "Q2",
                  "3": "Q3",
                  "4": "Q4"
                },
                "narrow": {
                  "1": "1",
                  "2": "2",
                  "3": "3",
                  "4": "4"
                },
                "wide": {
                  "1": "1st quarter",
                  "2": "2nd quarter",
                  "3": "3rd quarter",
                  "4": "4th quarter"
                }
              }
            },
            "dayPeriods": {
              "format": {
                "abbreviated": {
                  "am": "AM",
                  "am-alt-variant": "am",
                  "noon": "noon",
                  "pm": "PM",
                  "pm-alt-variant": "pm"
                },
                "narrow": {
                  "am": "a",
                  "noon": "n",
                  "pm": "p"
                },
                "wide": {
                  "am": "AM",
                  "am-alt-variant": "am",
                  "noon": "noon",
                  "pm": "PM",
                  "pm-alt-variant": "pm"
                }
              },
              "stand-alone": {
                "abbreviated": {
                  "am": "AM",
                  "am-alt-variant": "am",
                  "noon": "noon",
                  "pm": "PM",
                  "pm-alt-variant": "pm"
                },
                "narrow": {
                  "am": "a",
                  "noon": "n",
                  "pm": "p"
                },
                "wide": {
                  "am": "AM",
                  "am-alt-variant": "am",
                  "noon": "noon",
                  "pm": "PM",
                  "pm-alt-variant": "pm"
                }
              }
            },
            "eras": {
              "eraNames": {
                "0": "ERA0"
              },
              "eraAbbr": {
                "0": "ERA0"
              },
              "eraNarrow": {
                "0": "ERA0"
              }
            },
            "dateFormats": {
              "full": "EEEE, MMMM d, y G",
              "long": "MMMM d, y G",
              "medium": "MMM d, y G",
              "short": "M/d/y GGGGG"
            },
            "timeFormats": {
              "full": "h:mm:ss a zzzz",
              "long": "h:mm:ss a z",
              "medium": "h:mm:ss a",
              "short": "h:mm a"
            },
            "dateTimeFormats": {
              "full": "{1} 'at' {0}",
              "long": "{1} 'at' {0}",
              "medium": "{1}, {0}",
              "short": "{1}, {0}",
              "availableFormats": {
                "E": "ccc",
                "EHm": "E HH:mm",
                "EHms": "E HH:mm:ss",
                "Ed": "d E",
                "Ehm": "E h:mm a",
                "Ehms": "E h:mm:ss a",
                "Gy": "y G",
                "GyMMM": "MMM y G",
                "GyMMMEd": "E, MMM d, y G",
                "GyMMMd": "MMM d, y G",
                "H": "HH",
                "Hm": "HH:mm",
                "Hms": "HH:mm:ss",
                "M": "L",
                "MEd": "E, M/d",
                "MMM": "LLL",
                "MMMEd": "E, MMM d",
                "MMMd": "MMM d",
                "Md": "M/d",
                "d": "d",
                "h": "h a",
                "hm": "h:mm a",
                "hms": "h:mm:ss a",
                "ms": "mm:ss",
                "y": "y G",
                "yyyy": "y G",
                "yyyyM": "M/y GGGGG",
                "yyyyMEd": "E, M/d/y GGGGG",
                "yyyyMMM": "MMM y G",
                "yyyyMMMEd": "E, MMM d, y G",
                "yyyyMMMd": "MMM d, y G",
                "yyyyMd": "M/d/y GGGGG",
                "yyyyQQQ": "QQQ y G",
                "yyyyQQQQ": "QQQQ y G"
              },
              "appendItems": {
                "Day": "{0} ({2}: {1})",
                "Day-Of-Week": "{0} {1}",
                "Era": "{0} {1}",
                "Hour": "{0} ({2}: {1})",
                "Minute": "{0} ({2}: {1})",
                "Month": "{0} ({2}: {1})",
                "Quarter": "{0} ({2}: {1})",
                "Second": "{0} ({2}: {1})",
                "Timezone": "{0} {1}",
                "Week": "{0} ({2}: {1})",
                "Year": "{0} {1}"
              },
              "intervalFormats": {
                "intervalFormatFallback": "{0} – {1}",
                "H": {
                  "H": "HH – HH"
                },
                "Hm": {
                  "H": "HH:mm – HH:mm",
                  "m": "HH:mm – HH:mm"
                },
                "Hmv": {
                  "H": "HH:mm – HH:mm v",
                  "m": "HH:mm – HH:mm v"
                },
                "Hv": {
                  "H": "HH – HH v"
                },
                "M": {
                  "M": "M – M"
                },
                "MEd": {
                  "M": "E, M/d – E, M/d",
                  "d": "E, M/d – E, M/d"
                },
                "MMM": {
                  "M": "MMM – MMM"
                },
                "MMMEd": {
                  "M": "E, MMM d – E, MMM d",
                  "d": "E, MMM d – E, MMM d"
                },
                "MMMd": {
                  "M": "MMM d – MMM d",
                  "d": "MMM d – d"
                },
                "Md": {
                  "M": "M/d – M/d",
                  "d": "M/d – M/d"
                },
                "d": {
                  "d": "d – d"
                },
                "h": {
                  "a": "h a – h a",
                  "h": "h – h a"
                },
                "hm": {
                  "a": "h:mm a – h:mm a",
                  "h": "h:mm – h:mm a",
                  "m": "h:mm – h:mm a"
                },
                "hmv": {
                  "a": "h:mm a – h:mm a v",
                  "h": "h:mm – h:mm a v",
                  "m": "h:mm – h:mm a v"
                },
                "hv": {
                  "a": "h a – h a v",
                  "h": "h – h a v"
                },
                "y": {
                  "y": "y – y G"
                },
                "yM": {
                  "M": "M/y – M/y GGGGG",
                  "y": "M/y – M/y GGGGG"
                },
                "yMEd": {
                  "M": "E, M/d/y – E, M/d/y GGGGG",
                  "d": "E, M/d/y – E, M/d/y GGGGG",
                  "y": "E, M/d/y – E, M/d/y GGGGG"
                },
                "yMMM": {
                  "M": "MMM – MMM y G",
                  "y": "MMM y – MMM y G"
                },
                "yMMMEd": {
                  "M": "E, MMM d – E, MMM d, y G",
                  "d": "E, MMM d – E, MMM d, y G",
                  "y": "E, MMM d, y – E, MMM d, y G"
                },
                "yMMMM": {
                  "M": "MMMM – MMMM y G",
                  "y": "MMMM y – MMMM y G"
                },
                "yMMMd": {
                  "M": "MMM d – MMM d, y G",
                  "d": "MMM d – d, y G",
                  "y": "MMM d, y – MMM d, y G"
                },
                "yMd": {
                  "M": "M/d/y – M/d/y GGGGG",
                  "d": "M/d/y – M/d/y GGGGG",
                  "y": "M/d/y – M/d/y GGGGG"
                }
              }
            }
          }
        }
      }
    }
  }
}
)