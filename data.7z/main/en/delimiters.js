Globalize.load({
  "main": {
    "en": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10887 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-31 14:23:52 -0500 (Sun, 31 Aug 2014) $"
        },
        "language": "en"
      },
      "delimiters": {
        "quotationStart": "“",
        "quotationEnd": "”",
        "alternateQuotationStart": "‘",
        "alternateQuotationEnd": "’"
      }
    }
  }
}
)