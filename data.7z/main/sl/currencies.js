Globalize.load({
  "main": {
    "sl": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "root"
      },
      "numbers": {
        "currencies": {
          "ADP": {
            "displayName": "andorska peseta",
            "symbol": "ADP"
          },
          "AED": {
            "displayName": "dirham Združenih arabskih emiratov",
            "displayName-count-one": "dirham Združenih arabskih emiratov",
            "displayName-count-two": "dirham Združenih arabskih emiratov",
            "displayName-count-few": "dirham Združenih arabskih emiratov",
            "displayName-count-other": "dirham Združenih arabskih emiratov",
            "symbol": "AED"
          },
          "AFA": {
            "displayName": "stari afganistanski afgani (1927–2002)",
            "symbol": "AFA"
          },
          "AFN": {
            "displayName": "afgani",
            "displayName-count-one": "afgani",
            "displayName-count-two": "afgani",
            "displayName-count-few": "afgani",
            "displayName-count-other": "afgani",
            "symbol": "AFN"
          },
          "ALL": {
            "displayName": "albanski lek",
            "displayName-count-one": "albanski lek",
            "displayName-count-two": "albanski lek",
            "displayName-count-few": "albanski lek",
            "displayName-count-other": "albanski lek",
            "symbol": "ALL"
          },
          "AMD": {
            "displayName": "armenski dram",
            "displayName-count-one": "armenski dram",
            "displayName-count-two": "armenski dram",
            "displayName-count-few": "armenski dram",
            "displayName-count-other": "armenski dram",
            "symbol": "AMD"
          },
          "ANG": {
            "displayName": "nizozemsko-antilski gulden",
            "displayName-count-one": "nizozemsko-antilski gulden",
            "displayName-count-two": "nizozemsko-antilski gulden",
            "displayName-count-few": "nizozemsko-antilski gulden",
            "displayName-count-other": "nizozemsko-antilski gulden",
            "symbol": "ANG"
          },
          "AOA": {
            "displayName": "angolska kvanza",
            "displayName-count-one": "angolska kvanza",
            "displayName-count-two": "angolska kvanza",
            "displayName-count-few": "angolska kvanza",
            "displayName-count-other": "angolska kvanza",
            "symbol": "AOA",
            "symbol-alt-narrow": "Kz"
          },
          "AOK": {
            "displayName": "stara angolska kvanza (1977–1990)",
            "symbol": "AOK"
          },
          "AON": {
            "displayName": "angolska nova kvanza (1990–2000)",
            "symbol": "AON"
          },
          "AOR": {
            "displayName": "konvertibilna angolska kvanza (1995–1999)",
            "symbol": "AOR"
          },
          "ARA": {
            "displayName": "argentinski avstral",
            "symbol": "ARA"
          },
          "ARL": {
            "displayName": "ARL",
            "symbol": "ARL"
          },
          "ARM": {
            "displayName": "ARM",
            "symbol": "ARM"
          },
          "ARP": {
            "displayName": "argentinski peso (1983–1985)",
            "symbol": "ARP"
          },
          "ARS": {
            "displayName": "argentinski peso",
            "displayName-count-one": "argentinski peso",
            "displayName-count-two": "argentinski peso",
            "displayName-count-few": "argentinski peso",
            "displayName-count-other": "argentinski peso",
            "symbol": "ARS",
            "symbol-alt-narrow": "$"
          },
          "ATS": {
            "displayName": "avstrijski šiling",
            "symbol": "ATS"
          },
          "AUD": {
            "displayName": "avstralski dolar",
            "displayName-count-one": "avstralski dolar",
            "displayName-count-two": "avstralska dolarja",
            "displayName-count-few": "avstralski dolarji",
            "displayName-count-other": "avstralskih dolarjev",
            "symbol": "A$",
            "symbol-alt-narrow": "$"
          },
          "AWG": {
            "displayName": "arubski florin",
            "displayName-count-one": "arubski florin",
            "displayName-count-two": "arubski florin",
            "displayName-count-few": "arubski florin",
            "displayName-count-other": "arubski florin",
            "symbol": "AWG"
          },
          "AZM": {
            "displayName": "stari azerbajdžanski manat (1993–2006)",
            "symbol": "AZM"
          },
          "AZN": {
            "displayName": "azerbajdžanski manat",
            "displayName-count-one": "azerbajdžanski manat",
            "displayName-count-two": "azerbajdžanski manat",
            "displayName-count-few": "azerbajdžanski manat",
            "displayName-count-other": "azerbajdžanski manat",
            "symbol": "AZN"
          },
          "BAD": {
            "displayName": "bosansko-hercegovski dinar",
            "symbol": "BAD"
          },
          "BAM": {
            "displayName": "bosansko-hercegovska konvertibilna marka",
            "displayName-count-one": "bosansko-hercegovska konvertibilna marka",
            "displayName-count-two": "bosansko-hercegovski konvertibilni marki",
            "displayName-count-few": "bosansko-hercegovske konvertibilne marke",
            "displayName-count-other": "bosansko-hercegovskih konvertibilnih mark",
            "symbol": "BAM",
            "symbol-alt-narrow": "KM"
          },
          "BAN": {
            "displayName": "BAN",
            "symbol": "BAN"
          },
          "BBD": {
            "displayName": "barbadoški dolar",
            "displayName-count-one": "barbadoški dolar",
            "displayName-count-two": "barbadoški dolar",
            "displayName-count-few": "barbadoški dolar",
            "displayName-count-other": "barbadoški dolar",
            "symbol": "BBD",
            "symbol-alt-narrow": "$"
          },
          "BDT": {
            "displayName": "bangladeška taka",
            "displayName-count-one": "bangladeška taka",
            "displayName-count-two": "bangladeška taka",
            "displayName-count-few": "bangladeška taka",
            "displayName-count-other": "bangladeška taka",
            "symbol": "BDT",
            "symbol-alt-narrow": "৳"
          },
          "BEC": {
            "displayName": "belgijski konvertibilni frank",
            "symbol": "BEC"
          },
          "BEF": {
            "displayName": "belgijski frank",
            "displayName-count-one": "belgijski frank",
            "displayName-count-two": "belgijska franka",
            "displayName-count-few": "belgijski franki",
            "displayName-count-other": "belgijskih frankov",
            "symbol": "BEF"
          },
          "BEL": {
            "displayName": "belgijski finančni frank",
            "symbol": "BEL"
          },
          "BGL": {
            "displayName": "stari bolgarski lev",
            "symbol": "BGL"
          },
          "BGM": {
            "displayName": "BGM",
            "symbol": "BGM"
          },
          "BGN": {
            "displayName": "bolgarski lev",
            "displayName-count-one": "bolgarski lev",
            "displayName-count-two": "bolgarski lev",
            "displayName-count-few": "bolgarski lev",
            "displayName-count-other": "bolgarski lev",
            "symbol": "BGN"
          },
          "BGO": {
            "displayName": "BGO",
            "symbol": "BGO"
          },
          "BHD": {
            "displayName": "bahranski dinar",
            "displayName-count-one": "bahranski dinar",
            "displayName-count-two": "bahranski dinar",
            "displayName-count-few": "bahranski dinar",
            "displayName-count-other": "bahranski dinar",
            "symbol": "BHD"
          },
          "BIF": {
            "displayName": "burundski frank",
            "displayName-count-one": "burundski frank",
            "displayName-count-two": "burundski frank",
            "displayName-count-few": "burundski frank",
            "displayName-count-other": "burundski frank",
            "symbol": "BIF"
          },
          "BMD": {
            "displayName": "bermudski dolar",
            "displayName-count-one": "bermudski dolar",
            "displayName-count-two": "bermudski dolar",
            "displayName-count-few": "bermudski dolar",
            "displayName-count-other": "bermudski dolar",
            "symbol": "BMD",
            "symbol-alt-narrow": "$"
          },
          "BND": {
            "displayName": "brunejski dolar",
            "displayName-count-one": "brunejski dolar",
            "displayName-count-two": "brunejski dolar",
            "displayName-count-few": "brunejski dolar",
            "displayName-count-other": "brunejski dolar",
            "symbol": "BND",
            "symbol-alt-narrow": "$"
          },
          "BOB": {
            "displayName": "bolivijski boliviano",
            "displayName-count-one": "bolivijski boliviano",
            "displayName-count-two": "bolivijski boliviano",
            "displayName-count-few": "bolivijski boliviano",
            "displayName-count-other": "bolivijski boliviano",
            "symbol": "BOB",
            "symbol-alt-narrow": "Bs"
          },
          "BOL": {
            "displayName": "BOL",
            "symbol": "BOL"
          },
          "BOP": {
            "displayName": "bolivijski peso",
            "symbol": "BOP"
          },
          "BOV": {
            "displayName": "bolivijski mvdol",
            "symbol": "BOV"
          },
          "BRB": {
            "displayName": "brazilski novi kruzeiro (1967–1986)",
            "symbol": "BRB"
          },
          "BRC": {
            "displayName": "brazilski kruzado",
            "symbol": "BRC"
          },
          "BRE": {
            "displayName": "stari brazilski kruzeiro (1990–1993)",
            "symbol": "BRE"
          },
          "BRL": {
            "displayName": "brazilski real",
            "displayName-count-one": "brazilski real",
            "displayName-count-two": "brazilski real",
            "displayName-count-few": "brazilski real",
            "displayName-count-other": "brazilski real",
            "symbol": "R$",
            "symbol-alt-narrow": "R$"
          },
          "BRN": {
            "displayName": "novi brazilski kruzado",
            "symbol": "BRN"
          },
          "BRR": {
            "displayName": "brazilski kruzeiro",
            "symbol": "BRR"
          },
          "BRZ": {
            "displayName": "BRZ",
            "symbol": "BRZ"
          },
          "BSD": {
            "displayName": "bahamski dolar",
            "displayName-count-one": "bahamski dolar",
            "displayName-count-two": "bahamski dolar",
            "displayName-count-few": "bahamski dolar",
            "displayName-count-other": "bahamski dolar",
            "symbol": "BSD",
            "symbol-alt-narrow": "$"
          },
          "BTN": {
            "displayName": "butanski ngultrum",
            "displayName-count-one": "butanski ngultrum",
            "displayName-count-two": "butanski ngultrum",
            "displayName-count-few": "butanski ngultrum",
            "displayName-count-other": "butanski ngultrum",
            "symbol": "BTN"
          },
          "BUK": {
            "displayName": "burmanski kjat",
            "symbol": "BUK"
          },
          "BWP": {
            "displayName": "bocvanska pula",
            "displayName-count-one": "bocvanska pula",
            "displayName-count-two": "bocvanska pula",
            "displayName-count-few": "bocvanska pula",
            "displayName-count-other": "bocvanska pula",
            "symbol": "BWP",
            "symbol-alt-narrow": "P"
          },
          "BYB": {
            "displayName": "beloruski novi rubelj (1994–1999)",
            "symbol": "BYB"
          },
          "BYR": {
            "displayName": "beloruski rubelj",
            "displayName-count-one": "beloruski rubelj",
            "displayName-count-two": "beloruski rubelj",
            "displayName-count-few": "beloruski rubelj",
            "displayName-count-other": "beloruski rubelj",
            "symbol": "BYR",
            "symbol-alt-narrow": "р."
          },
          "BZD": {
            "displayName": "belizejski dolar",
            "displayName-count-one": "belizejski dolar",
            "displayName-count-two": "belizejski dolar",
            "displayName-count-few": "belizejski dolar",
            "displayName-count-other": "belizejski dolar",
            "symbol": "BZD",
            "symbol-alt-narrow": "$"
          },
          "CAD": {
            "displayName": "kanadski dolar",
            "displayName-count-one": "kanadski dolar",
            "displayName-count-two": "kanadski dolar",
            "displayName-count-few": "kanadski dolar",
            "displayName-count-other": "kanadski dolar",
            "symbol": "CAD",
            "symbol-alt-narrow": "$"
          },
          "CDF": {
            "displayName": "kongoški frank",
            "displayName-count-one": "kongoški frank",
            "displayName-count-two": "kongoški frank",
            "displayName-count-few": "kongoški frank",
            "displayName-count-other": "kongoški frank",
            "symbol": "CDF"
          },
          "CHE": {
            "displayName": "evro WIR",
            "symbol": "CHE"
          },
          "CHF": {
            "displayName": "švicarski frank",
            "displayName-count-one": "švicarski frank",
            "displayName-count-two": "švicarski frank",
            "displayName-count-few": "švicarski frank",
            "displayName-count-other": "švicarski frank",
            "symbol": "CHF"
          },
          "CHW": {
            "displayName": "frank WIR",
            "symbol": "CHW"
          },
          "CLE": {
            "displayName": "CLE",
            "symbol": "CLE"
          },
          "CLF": {
            "displayName": "čilski unidades de fomento",
            "symbol": "CLF"
          },
          "CLP": {
            "displayName": "čilski peso",
            "displayName-count-one": "čilski peso",
            "displayName-count-two": "čilski peso",
            "displayName-count-few": "čilski peso",
            "displayName-count-other": "čilski peso",
            "symbol": "CLP",
            "symbol-alt-narrow": "$"
          },
          "CNY": {
            "displayName": "kitajski juan renminbi",
            "displayName-count-one": "kitajski juan renminbi",
            "displayName-count-two": "kitajski juan renminbi",
            "displayName-count-few": "kitajski juan renminbi",
            "displayName-count-other": "kitajski juan renminbi",
            "symbol": "CN¥",
            "symbol-alt-narrow": "¥"
          },
          "COP": {
            "displayName": "kolumbijski peso",
            "displayName-count-one": "kolumbijski peso",
            "displayName-count-two": "kolumbijski peso",
            "displayName-count-few": "kolumbijski peso",
            "displayName-count-other": "kolumbijski peso",
            "symbol": "COP",
            "symbol-alt-narrow": "$"
          },
          "COU": {
            "displayName": "kolumbijska enota realne vrednosti",
            "symbol": "COU"
          },
          "CRC": {
            "displayName": "kostariški kolon",
            "displayName-count-one": "kostariški kolon",
            "displayName-count-two": "kostariški kolon",
            "displayName-count-few": "kostariški kolon",
            "displayName-count-other": "kostariški kolon",
            "symbol": "CRC",
            "symbol-alt-narrow": "₡"
          },
          "CSD": {
            "displayName": "stari srbski dinar",
            "symbol": "CSD"
          },
          "CSK": {
            "displayName": "češkoslovaška krona",
            "symbol": "CSK"
          },
          "CUC": {
            "displayName": "kubanski konvertibilni peso",
            "displayName-count-one": "kubanski konvertibilni peso",
            "displayName-count-two": "kubanski konvertibilni peso",
            "displayName-count-few": "kubanski konvertibilni peso",
            "displayName-count-other": "kubanski konvertibilni peso",
            "symbol": "CUC",
            "symbol-alt-narrow": "$"
          },
          "CUP": {
            "displayName": "kubanski peso",
            "displayName-count-one": "kubanski peso",
            "displayName-count-two": "kubanski peso",
            "displayName-count-few": "kubanski peso",
            "displayName-count-other": "kubanski peso",
            "symbol": "CUP",
            "symbol-alt-narrow": "$"
          },
          "CVE": {
            "displayName": "zelenortski eskudo",
            "displayName-count-one": "zelenortski eskudo",
            "displayName-count-two": "zelenortski eskudo",
            "displayName-count-few": "zelenortski eskudo",
            "displayName-count-other": "zelenortski eskudo",
            "symbol": "CVE"
          },
          "CYP": {
            "displayName": "ciprski funt",
            "symbol": "CYP"
          },
          "CZK": {
            "displayName": "češka krona",
            "displayName-count-one": "češka krona",
            "displayName-count-two": "češka krona",
            "displayName-count-few": "češka krona",
            "displayName-count-other": "češka krona",
            "symbol": "CZK",
            "symbol-alt-narrow": "Kč"
          },
          "DDM": {
            "displayName": "vzhodnonemška marka",
            "symbol": "DDM"
          },
          "DEM": {
            "displayName": "nemška marka",
            "displayName-count-one": "nemška marka",
            "displayName-count-two": "nemški marki",
            "displayName-count-few": "nemške marke",
            "displayName-count-other": "nemških mark",
            "symbol": "DEM"
          },
          "DJF": {
            "displayName": "džibutski frank",
            "displayName-count-one": "džibutski frank",
            "displayName-count-two": "džibutski frank",
            "displayName-count-few": "džibutski frank",
            "displayName-count-other": "džibutski frank",
            "symbol": "DJF"
          },
          "DKK": {
            "displayName": "danska krona",
            "displayName-count-one": "danska krona",
            "displayName-count-two": "danski kroni",
            "displayName-count-few": "danske krone",
            "displayName-count-other": "danskih kron",
            "symbol": "DKK",
            "symbol-alt-narrow": "kr"
          },
          "DOP": {
            "displayName": "dominikanski peso",
            "displayName-count-one": "dominikanski peso",
            "displayName-count-two": "dominikanski peso",
            "displayName-count-few": "dominikanski peso",
            "displayName-count-other": "dominikanski peso",
            "symbol": "DOP",
            "symbol-alt-narrow": "$"
          },
          "DZD": {
            "displayName": "alžirski dinar",
            "displayName-count-one": "alžirski dinar",
            "displayName-count-two": "alžirski dinar",
            "displayName-count-few": "alžirski dinar",
            "displayName-count-other": "alžirski dinar",
            "symbol": "DZD"
          },
          "ECS": {
            "displayName": "ekvadorski sukre",
            "symbol": "ECS"
          },
          "ECV": {
            "displayName": "ekvadorska enota realne vrednosti (UVC)",
            "symbol": "ECV"
          },
          "EEK": {
            "displayName": "estonska krona",
            "symbol": "EEK"
          },
          "EGP": {
            "displayName": "egiptovski funt",
            "displayName-count-one": "egiptovski funt",
            "displayName-count-two": "egiptovski funt",
            "displayName-count-few": "egiptovski funt",
            "displayName-count-other": "egiptovski funt",
            "symbol": "EGP",
            "symbol-alt-narrow": "E£"
          },
          "ERN": {
            "displayName": "eritrejska nakfa",
            "displayName-count-one": "eritrejska nakfa",
            "displayName-count-two": "eritrejska nakfa",
            "displayName-count-few": "eritrejska nakfa",
            "displayName-count-other": "eritrejska nakfa",
            "symbol": "ERN"
          },
          "ESA": {
            "displayName": "španska pezeta (račun A)",
            "symbol": "ESA"
          },
          "ESB": {
            "displayName": "španska pezeta (račun B)",
            "symbol": "ESB"
          },
          "ESP": {
            "displayName": "španska pezeta",
            "symbol": "ESP",
            "symbol-alt-narrow": "₧"
          },
          "ETB": {
            "displayName": "etiopski bir",
            "displayName-count-one": "etiopski bir",
            "displayName-count-two": "etiopski bir",
            "displayName-count-few": "etiopski bir",
            "displayName-count-other": "etiopski bir",
            "symbol": "ETB"
          },
          "EUR": {
            "displayName": "evro",
            "displayName-count-one": "evro",
            "displayName-count-two": "evra",
            "displayName-count-few": "evri",
            "displayName-count-other": "evrov",
            "symbol": "€",
            "symbol-alt-narrow": "€"
          },
          "FIM": {
            "displayName": "finska marka",
            "symbol": "FIM"
          },
          "FJD": {
            "displayName": "fidžijski dolar",
            "displayName-count-one": "fidžijski dolar",
            "displayName-count-two": "fidžijski dolar",
            "displayName-count-few": "fidžijski dolar",
            "displayName-count-other": "fidžijski dolar",
            "symbol": "FJD",
            "symbol-alt-narrow": "$"
          },
          "FKP": {
            "displayName": "falklandski funt",
            "displayName-count-one": "falklandski funt",
            "displayName-count-two": "falklandski funt",
            "displayName-count-few": "falklandski funt",
            "displayName-count-other": "falklandski funt",
            "symbol": "FKP",
            "symbol-alt-narrow": "£"
          },
          "FRF": {
            "displayName": "francoski frank",
            "symbol": "FRF"
          },
          "GBP": {
            "displayName": "britanski funt",
            "displayName-count-one": "britanski funt",
            "displayName-count-two": "britanskih funtov",
            "displayName-count-few": "britanski funti",
            "displayName-count-other": "britanskih funtov",
            "symbol": "£",
            "symbol-alt-narrow": "£"
          },
          "GEK": {
            "displayName": "gruzijski bon lari",
            "symbol": "GEK"
          },
          "GEL": {
            "displayName": "gruzijski lari",
            "displayName-count-one": "gruzijski lari",
            "displayName-count-two": "gruzijski lari",
            "displayName-count-few": "gruzijski lari",
            "displayName-count-other": "gruzijski lari",
            "symbol": "GEL"
          },
          "GHC": {
            "displayName": "stari ganski cedi (1979–2007)",
            "symbol": "GHC"
          },
          "GHS": {
            "displayName": "ganski cedi",
            "displayName-count-one": "ganski cedi",
            "displayName-count-two": "ganski cedi",
            "displayName-count-few": "ganski cedi",
            "displayName-count-other": "ganski cedi",
            "symbol": "GHS"
          },
          "GIP": {
            "displayName": "gibraltarski funt",
            "displayName-count-one": "gibraltarski funt",
            "displayName-count-two": "gibraltarski funt",
            "displayName-count-few": "gibraltarski funt",
            "displayName-count-other": "gibraltarski funt",
            "symbol": "GIP",
            "symbol-alt-narrow": "£"
          },
          "GMD": {
            "displayName": "gambijski dalasi",
            "displayName-count-one": "gambijski dalasi",
            "displayName-count-two": "gambijski dalasi",
            "displayName-count-few": "gambijski dalasi",
            "displayName-count-other": "gambijski dalasi",
            "symbol": "GMD"
          },
          "GNF": {
            "displayName": "gvinejski frank",
            "displayName-count-one": "gvinejski frank",
            "displayName-count-two": "gvinejski frank",
            "displayName-count-few": "gvinejski frank",
            "displayName-count-other": "gvinejski frank",
            "symbol": "GNF",
            "symbol-alt-narrow": "FG"
          },
          "GNS": {
            "displayName": "gvinejski sili",
            "symbol": "GNS"
          },
          "GQE": {
            "displayName": "ekwele Ekvatorialne Gvineje",
            "symbol": "GQE"
          },
          "GRD": {
            "displayName": "grška drahma",
            "symbol": "GRD"
          },
          "GTQ": {
            "displayName": "gvatemalski kecal",
            "displayName-count-one": "gvatemalski kecal",
            "displayName-count-two": "gvatemalski kecal",
            "displayName-count-few": "gvatemalski kecal",
            "displayName-count-other": "gvatemalski kecal",
            "symbol": "GTQ",
            "symbol-alt-narrow": "Q"
          },
          "GWE": {
            "displayName": "eskudo Portugalske Gvineje",
            "symbol": "GWE"
          },
          "GWP": {
            "displayName": "peso Gvineje Bissau",
            "symbol": "GWP"
          },
          "GYD": {
            "displayName": "gvajanski dolar",
            "displayName-count-one": "gvajanski dolar",
            "displayName-count-two": "gvajanski dolar",
            "displayName-count-few": "gvajanski dolar",
            "displayName-count-other": "gvajanski dolar",
            "symbol": "GYD",
            "symbol-alt-narrow": "$"
          },
          "HKD": {
            "displayName": "hongkonški dolar",
            "displayName-count-one": "hongkonški dolar",
            "displayName-count-two": "hongkonški dolar",
            "displayName-count-few": "hongkonški dolar",
            "displayName-count-other": "hongkonški dolar",
            "symbol": "HK$",
            "symbol-alt-narrow": "$"
          },
          "HNL": {
            "displayName": "honduraška lempira",
            "displayName-count-one": "honduraška lempira",
            "displayName-count-two": "honduraška lempira",
            "displayName-count-few": "honduraška lempira",
            "displayName-count-other": "honduraška lempira",
            "symbol": "HNL",
            "symbol-alt-narrow": "L"
          },
          "HRD": {
            "displayName": "hrvaški dinar",
            "symbol": "HRD"
          },
          "HRK": {
            "displayName": "hrvaška kuna",
            "displayName-count-one": "hrvaška kuna",
            "displayName-count-two": "hrvaška kuna",
            "displayName-count-few": "hrvaška kuna",
            "displayName-count-other": "hrvaška kuna",
            "symbol": "HRK",
            "symbol-alt-narrow": "kn"
          },
          "HTG": {
            "displayName": "haitski gurd",
            "displayName-count-one": "haitski gurd",
            "displayName-count-two": "haitski gurd",
            "displayName-count-few": "haitski gurd",
            "displayName-count-other": "haitski gurd",
            "symbol": "HTG"
          },
          "HUF": {
            "displayName": "madžarski forint",
            "displayName-count-one": "madžarski forint",
            "displayName-count-two": "madžarski forint",
            "displayName-count-few": "madžarski forint",
            "displayName-count-other": "madžarski forint",
            "symbol": "HUF",
            "symbol-alt-narrow": "Ft"
          },
          "IDR": {
            "displayName": "indonezijska rupija",
            "displayName-count-one": "indonezijska rupija",
            "displayName-count-two": "indonezijska rupija",
            "displayName-count-few": "indonezijska rupija",
            "displayName-count-other": "indonezijska rupija",
            "symbol": "IDR",
            "symbol-alt-narrow": "Rp"
          },
          "IEP": {
            "displayName": "irski funt",
            "symbol": "IEP"
          },
          "ILP": {
            "displayName": "izraelski funt",
            "symbol": "ILP"
          },
          "ILS": {
            "displayName": "izraelski šekel",
            "displayName-count-one": "izraelski šekel",
            "displayName-count-two": "izraelski šekel",
            "displayName-count-few": "izraelski šekel",
            "displayName-count-other": "izraelski šekel",
            "symbol": "₪",
            "symbol-alt-narrow": "₪"
          },
          "INR": {
            "displayName": "indijska rupija",
            "displayName-count-one": "indijska rupija",
            "displayName-count-two": "indijska rupija",
            "displayName-count-few": "indijska rupija",
            "displayName-count-other": "indijska rupija",
            "symbol": "₹",
            "symbol-alt-narrow": "₹"
          },
          "IQD": {
            "displayName": "iraški dinar",
            "displayName-count-one": "iraški dinar",
            "displayName-count-two": "iraški dinar",
            "displayName-count-few": "iraški dinar",
            "displayName-count-other": "iraški dinar",
            "symbol": "IQD"
          },
          "IRR": {
            "displayName": "iranski rial",
            "displayName-count-one": "iranski rial",
            "displayName-count-two": "iranski rial",
            "displayName-count-few": "iranski rial",
            "displayName-count-other": "iranski rial",
            "symbol": "IRR"
          },
          "ISK": {
            "displayName": "islandska krona",
            "displayName-count-one": "islandska krona",
            "displayName-count-two": "islandska krona",
            "displayName-count-few": "islandska krona",
            "displayName-count-other": "islandska krona",
            "symbol": "ISK",
            "symbol-alt-narrow": "kr"
          },
          "ITL": {
            "displayName": "italijanska lira",
            "symbol": "ITL"
          },
          "JMD": {
            "displayName": "jamajški dolar",
            "displayName-count-one": "jamajški dolar",
            "displayName-count-two": "jamajški dolar",
            "displayName-count-few": "jamajški dolar",
            "displayName-count-other": "jamajški dolar",
            "symbol": "JMD",
            "symbol-alt-narrow": "$"
          },
          "JOD": {
            "displayName": "jordanski dinar",
            "displayName-count-one": "jordanski dinar",
            "displayName-count-two": "jordanski dinar",
            "displayName-count-few": "jordanski dinar",
            "displayName-count-other": "jordanski dinar",
            "symbol": "JOD"
          },
          "JPY": {
            "displayName": "japonski jen",
            "displayName-count-one": "japonski jen",
            "displayName-count-two": "japonski jen",
            "displayName-count-few": "japonski jen",
            "displayName-count-other": "japonski jen",
            "symbol": "¥",
            "symbol-alt-narrow": "¥"
          },
          "KES": {
            "displayName": "kenijski šiling",
            "displayName-count-one": "kenijski šiling",
            "displayName-count-two": "kenijski šiling",
            "displayName-count-few": "kenijski šiling",
            "displayName-count-other": "kenijski šiling",
            "symbol": "KES"
          },
          "KGS": {
            "displayName": "kirgiški som",
            "displayName-count-one": "kirgiški som",
            "displayName-count-two": "kirgiški som",
            "displayName-count-few": "kirgiški som",
            "displayName-count-other": "kirgiški som",
            "symbol": "KGS"
          },
          "KHR": {
            "displayName": "kamboški riel",
            "displayName-count-one": "kamboški riel",
            "displayName-count-two": "kamboški riel",
            "displayName-count-few": "kamboški riel",
            "displayName-count-other": "kamboški riel",
            "symbol": "KHR",
            "symbol-alt-narrow": "៛"
          },
          "KMF": {
            "displayName": "komorski frank",
            "displayName-count-one": "komorski frank",
            "displayName-count-two": "komorski frank",
            "displayName-count-few": "komorski frank",
            "displayName-count-other": "komorski frank",
            "symbol": "KMF",
            "symbol-alt-narrow": "CF"
          },
          "KPW": {
            "displayName": "severnokorejski von",
            "displayName-count-one": "severnokorejski von",
            "displayName-count-two": "severnokorejski von",
            "displayName-count-few": "severnokorejski von",
            "displayName-count-other": "severnokorejski von",
            "symbol": "KPW",
            "symbol-alt-narrow": "₩"
          },
          "KRH": {
            "displayName": "KRH",
            "symbol": "KRH"
          },
          "KRO": {
            "displayName": "KRO",
            "symbol": "KRO"
          },
          "KRW": {
            "displayName": "južnokorejski von",
            "displayName-count-one": "južnokorejski von",
            "displayName-count-two": "južnokorejski von",
            "displayName-count-few": "južnokorejski von",
            "displayName-count-other": "južnokorejski von",
            "symbol": "₩",
            "symbol-alt-narrow": "₩"
          },
          "KWD": {
            "displayName": "kuvajtski dinar",
            "displayName-count-one": "kuvajtski dinar",
            "displayName-count-two": "kuvajtski dinar",
            "displayName-count-few": "kuvajtski dinar",
            "displayName-count-other": "kuvajtski dinar",
            "symbol": "KWD"
          },
          "KYD": {
            "displayName": "kajmanski dolar",
            "displayName-count-one": "kajmanski dolar",
            "displayName-count-two": "kajmanski dolar",
            "displayName-count-few": "kajmanski dolar",
            "displayName-count-other": "kajmanski dolar",
            "symbol": "KYD",
            "symbol-alt-narrow": "$"
          },
          "KZT": {
            "displayName": "kazahstanski tenge",
            "displayName-count-one": "kazahstanski tenge",
            "displayName-count-two": "kazahstanski tenge",
            "displayName-count-few": "kazahstanski tenge",
            "displayName-count-other": "kazahstanski tenge",
            "symbol": "KZT",
            "symbol-alt-narrow": "₸"
          },
          "LAK": {
            "displayName": "laoški kip",
            "displayName-count-one": "laoški kip",
            "displayName-count-two": "laoški kip",
            "displayName-count-few": "laoški kip",
            "displayName-count-other": "laoški kip",
            "symbol": "LAK",
            "symbol-alt-narrow": "₭"
          },
          "LBP": {
            "displayName": "libanonski funt",
            "displayName-count-one": "libanonski funt",
            "displayName-count-two": "libanonski funt",
            "displayName-count-few": "libanonski funt",
            "displayName-count-other": "libanonski funt",
            "symbol": "LBP",
            "symbol-alt-narrow": "L£"
          },
          "LKR": {
            "displayName": "šrilanška rupija",
            "displayName-count-one": "šrilanška rupija",
            "displayName-count-two": "šrilanška rupija",
            "displayName-count-few": "šrilanška rupija",
            "displayName-count-other": "šrilanška rupija",
            "symbol": "LKR",
            "symbol-alt-narrow": "Rs"
          },
          "LRD": {
            "displayName": "liberijski dolar",
            "displayName-count-one": "liberijski dolar",
            "displayName-count-two": "liberijski dolar",
            "displayName-count-few": "liberijski dolar",
            "displayName-count-other": "liberijski dolar",
            "symbol": "LRD",
            "symbol-alt-narrow": "$"
          },
          "LSL": {
            "displayName": "lesoški loti",
            "symbol": "LSL"
          },
          "LTL": {
            "displayName": "litovski litas",
            "displayName-count-one": "litovski litas",
            "displayName-count-two": "litovski litas",
            "displayName-count-few": "litovski litas",
            "displayName-count-other": "litovski litas",
            "symbol": "LTL",
            "symbol-alt-narrow": "Lt"
          },
          "LTT": {
            "displayName": "litvanski litas",
            "symbol": "LTT"
          },
          "LUC": {
            "displayName": "luksemburški konvertibilni frank",
            "symbol": "LUC"
          },
          "LUF": {
            "displayName": "luksemburški frank",
            "symbol": "LUF"
          },
          "LUL": {
            "displayName": "luksemburški finančni frank",
            "symbol": "LUL"
          },
          "LVL": {
            "displayName": "latvijski lats",
            "displayName-count-one": "latvijski lats",
            "displayName-count-two": "latvijski lats",
            "displayName-count-few": "latvijski lats",
            "displayName-count-other": "latvijski lats",
            "symbol": "LVL",
            "symbol-alt-narrow": "Ls"
          },
          "LVR": {
            "displayName": "latvijski rubelj",
            "symbol": "LVR"
          },
          "LYD": {
            "displayName": "libijski dinar",
            "displayName-count-one": "libijski dinar",
            "displayName-count-two": "libijski dinar",
            "displayName-count-few": "libijski dinar",
            "displayName-count-other": "libijski dinar",
            "symbol": "LYD"
          },
          "MAD": {
            "displayName": "maroški dirham",
            "displayName-count-one": "maroški dirham",
            "displayName-count-two": "maroški dirham",
            "displayName-count-few": "maroški dirham",
            "displayName-count-other": "maroški dirham",
            "symbol": "MAD"
          },
          "MAF": {
            "displayName": "maroški frank",
            "symbol": "MAF"
          },
          "MCF": {
            "displayName": "MCF",
            "symbol": "MCF"
          },
          "MDC": {
            "displayName": "MDC",
            "symbol": "MDC"
          },
          "MDL": {
            "displayName": "moldavijski leu",
            "displayName-count-one": "moldavijski leu",
            "displayName-count-two": "moldavijski leu",
            "displayName-count-few": "moldavijski leu",
            "displayName-count-other": "moldavijski leu",
            "symbol": "MDL"
          },
          "MGA": {
            "displayName": "malgaški ariarij",
            "displayName-count-one": "malgaški ariarij",
            "displayName-count-two": "malgaški ariarij",
            "displayName-count-few": "malgaški ariarij",
            "displayName-count-other": "malgaški ariarij",
            "symbol": "MGA",
            "symbol-alt-narrow": "Ar"
          },
          "MGF": {
            "displayName": "malgaški frank",
            "symbol": "MGF"
          },
          "MKD": {
            "displayName": "makedonski denar",
            "displayName-count-one": "makedonski denar",
            "displayName-count-two": "makedonski denar",
            "displayName-count-few": "makedonski denar",
            "displayName-count-other": "makedonski denar",
            "symbol": "MKD"
          },
          "MKN": {
            "displayName": "MKN",
            "symbol": "MKN"
          },
          "MLF": {
            "displayName": "malijski frank",
            "symbol": "MLF"
          },
          "MMK": {
            "displayName": "mjanmarski kjat",
            "displayName-count-one": "mjanmarski kjat",
            "displayName-count-two": "mjanmarski kjat",
            "displayName-count-few": "mjanmarski kjat",
            "displayName-count-other": "mjanmarski kjat",
            "symbol": "MMK",
            "symbol-alt-narrow": "K"
          },
          "MNT": {
            "displayName": "mongolski tugrik",
            "displayName-count-one": "mongolski tugrik",
            "displayName-count-two": "mongolski tugrik",
            "displayName-count-few": "mongolski tugrik",
            "displayName-count-other": "mongolski tugrik",
            "symbol": "MNT",
            "symbol-alt-narrow": "₮"
          },
          "MOP": {
            "displayName": "makavska pataka",
            "displayName-count-one": "makavska pataka",
            "displayName-count-two": "makavska pataka",
            "displayName-count-few": "makavska pataka",
            "displayName-count-other": "makavska pataka",
            "symbol": "MOP"
          },
          "MRO": {
            "displayName": "mavretanska uguija",
            "displayName-count-one": "mavretanska uguija",
            "displayName-count-two": "mavretanska uguija",
            "displayName-count-few": "mavretanska uguija",
            "displayName-count-other": "mavretanska uguija",
            "symbol": "MRO"
          },
          "MTL": {
            "displayName": "malteška lira",
            "symbol": "MTL"
          },
          "MTP": {
            "displayName": "malteški funt",
            "symbol": "MTP"
          },
          "MUR": {
            "displayName": "mavricijska rupija",
            "displayName-count-one": "mavricijska rupija",
            "displayName-count-two": "mavricijska rupija",
            "displayName-count-few": "mavricijska rupija",
            "displayName-count-other": "mavricijska rupija",
            "symbol": "MUR",
            "symbol-alt-narrow": "Rs"
          },
          "MVR": {
            "displayName": "maldivska rufija",
            "displayName-count-one": "maldivska rufija",
            "displayName-count-two": "maldivska rufija",
            "displayName-count-few": "maldivska rufija",
            "displayName-count-other": "maldivska rufija",
            "symbol": "MVR"
          },
          "MWK": {
            "displayName": "malavijska kvača",
            "displayName-count-one": "malavijska kvača",
            "displayName-count-two": "malavijska kvača",
            "displayName-count-few": "malavijska kvača",
            "displayName-count-other": "malavijska kvača",
            "symbol": "MWK"
          },
          "MXN": {
            "displayName": "mehiški peso",
            "displayName-count-one": "mehiški peso",
            "displayName-count-two": "mehiški peso",
            "displayName-count-few": "mehiški peso",
            "displayName-count-other": "mehiški peso",
            "symbol": "MX$",
            "symbol-alt-narrow": "$"
          },
          "MXP": {
            "displayName": "mehiški srebrni peso (1861–1992)",
            "symbol": "MXP"
          },
          "MXV": {
            "displayName": "mehiška inverzna enota (UDI)",
            "symbol": "MXV"
          },
          "MYR": {
            "displayName": "malezijski ringit",
            "displayName-count-one": "malezijski ringit",
            "displayName-count-two": "malezijski ringit",
            "displayName-count-few": "malezijski ringit",
            "displayName-count-other": "malezijski ringit",
            "symbol": "MYR",
            "symbol-alt-narrow": "RM"
          },
          "MZE": {
            "displayName": "mozambiški eskudo",
            "symbol": "MZE"
          },
          "MZM": {
            "displayName": "stari mozambiški metikal",
            "symbol": "MZM"
          },
          "MZN": {
            "displayName": "mozambiški metikal",
            "displayName-count-one": "mozambiški metikal",
            "displayName-count-two": "mozambiški metikal",
            "displayName-count-few": "mozambiški metikal",
            "displayName-count-other": "mozambiški metikal",
            "symbol": "MZN"
          },
          "NAD": {
            "displayName": "namibijski dolar",
            "displayName-count-one": "namibijski dolar",
            "displayName-count-two": "namibijski dolar",
            "displayName-count-few": "namibijski dolar",
            "displayName-count-other": "namibijski dolar",
            "symbol": "NAD",
            "symbol-alt-narrow": "$"
          },
          "NGN": {
            "displayName": "nigerijska naira",
            "displayName-count-one": "nigerijska naira",
            "displayName-count-two": "nigerijska naira",
            "displayName-count-few": "nigerijska naira",
            "displayName-count-other": "nigerijska naira",
            "symbol": "NGN",
            "symbol-alt-narrow": "₦"
          },
          "NIC": {
            "displayName": "nikaraška kordova",
            "symbol": "NIC"
          },
          "NIO": {
            "displayName": "nikaraška zlata kordova",
            "displayName-count-one": "nikaraška zlata kordova",
            "displayName-count-two": "nikaraška zlata kordova",
            "displayName-count-few": "nikaraška zlata kordova",
            "displayName-count-other": "nikaraška zlata kordova",
            "symbol": "NIO",
            "symbol-alt-narrow": "C$"
          },
          "NLG": {
            "displayName": "nizozemski gulden",
            "symbol": "NLG"
          },
          "NOK": {
            "displayName": "norveška krona",
            "displayName-count-one": "norveška krona",
            "displayName-count-two": "norveška krona",
            "displayName-count-few": "norveška krona",
            "displayName-count-other": "norveška krona",
            "symbol": "NOK",
            "symbol-alt-narrow": "kr"
          },
          "NPR": {
            "displayName": "nepalska rupija",
            "displayName-count-one": "nepalska rupija",
            "displayName-count-two": "nepalska rupija",
            "displayName-count-few": "nepalska rupija",
            "displayName-count-other": "nepalska rupija",
            "symbol": "NPR",
            "symbol-alt-narrow": "Rs"
          },
          "NZD": {
            "displayName": "novozelandski dolar",
            "displayName-count-one": "novozelandski dolar",
            "displayName-count-two": "novozelandski dolar",
            "displayName-count-few": "novozelandski dolar",
            "displayName-count-other": "novozelandski dolar",
            "symbol": "NZ$",
            "symbol-alt-narrow": "$"
          },
          "OMR": {
            "displayName": "omanski rial",
            "displayName-count-one": "omanski rial",
            "displayName-count-two": "omanski rial",
            "displayName-count-few": "omanski rial",
            "displayName-count-other": "omanski rial",
            "symbol": "OMR"
          },
          "PAB": {
            "displayName": "panamska balboa",
            "displayName-count-one": "panamska balboa",
            "displayName-count-two": "panamska balboa",
            "displayName-count-few": "panamska balboa",
            "displayName-count-other": "panamska balboa",
            "symbol": "PAB"
          },
          "PEI": {
            "displayName": "perujski inti",
            "symbol": "PEI"
          },
          "PEN": {
            "displayName": "perujski novi sol",
            "displayName-count-one": "perujski novi sol",
            "displayName-count-two": "perujski novi sol",
            "displayName-count-few": "perujski novi sol",
            "displayName-count-other": "perujski novi sol",
            "symbol": "PEN"
          },
          "PES": {
            "displayName": "perujski sol",
            "symbol": "PES"
          },
          "PGK": {
            "displayName": "kina Papue Nove Gvineje",
            "displayName-count-one": "kina Papue Nove Gvineje",
            "displayName-count-two": "kina Papue Nove Gvineje",
            "displayName-count-few": "kina Papue Nove Gvineje",
            "displayName-count-other": "kina Papue Nove Gvineje",
            "symbol": "PGK"
          },
          "PHP": {
            "displayName": "filipinski peso",
            "displayName-count-one": "filipinski peso",
            "displayName-count-two": "filipinski peso",
            "displayName-count-few": "filipinski peso",
            "displayName-count-other": "filipinski peso",
            "symbol": "PHP",
            "symbol-alt-narrow": "₱"
          },
          "PKR": {
            "displayName": "pakistanska rupija",
            "displayName-count-one": "pakistanska rupija",
            "displayName-count-two": "pakistanska rupija",
            "displayName-count-few": "pakistanska rupija",
            "displayName-count-other": "pakistanska rupija",
            "symbol": "PKR",
            "symbol-alt-narrow": "Rs"
          },
          "PLN": {
            "displayName": "poljski novi zlot",
            "displayName-count-one": "poljski novi zlot",
            "displayName-count-two": "poljski novi zlot",
            "displayName-count-few": "poljski novi zlot",
            "displayName-count-other": "poljski novi zlot",
            "symbol": "PLN",
            "symbol-alt-narrow": "zł"
          },
          "PLZ": {
            "displayName": "stari poljski zlot (1950–1995)",
            "symbol": "PLZ"
          },
          "PTE": {
            "displayName": "portugalski eskudo",
            "symbol": "PTE"
          },
          "PYG": {
            "displayName": "paragvajski gvarani",
            "displayName-count-one": "paragvajski gvarani",
            "displayName-count-two": "paragvajski gvarani",
            "displayName-count-few": "paragvajski gvarani",
            "displayName-count-other": "paragvajski gvarani",
            "symbol": "PYG",
            "symbol-alt-narrow": "₲"
          },
          "QAR": {
            "displayName": "katarski rial",
            "displayName-count-one": "katarski rial",
            "displayName-count-two": "katarski rial",
            "displayName-count-few": "katarski rial",
            "displayName-count-other": "katarski rial",
            "symbol": "QAR"
          },
          "RHD": {
            "displayName": "rodezijski dolar",
            "symbol": "RHD"
          },
          "ROL": {
            "displayName": "stari romunski leu",
            "symbol": "ROL"
          },
          "RON": {
            "displayName": "romunski leu",
            "displayName-count-one": "romunski leu",
            "displayName-count-two": "romunski leu",
            "displayName-count-few": "romunski leu",
            "displayName-count-other": "romunski leu",
            "symbol": "RON"
          },
          "RSD": {
            "displayName": "srbski dinar",
            "displayName-count-one": "srbski dinar",
            "displayName-count-two": "srbski dinar",
            "displayName-count-few": "srbski dinar",
            "displayName-count-other": "srbski dinar",
            "symbol": "RSD"
          },
          "RUB": {
            "displayName": "ruski rubelj",
            "displayName-count-one": "ruski rubelj",
            "displayName-count-two": "ruski rubelj",
            "displayName-count-few": "ruski rubelj",
            "displayName-count-other": "ruski rubelj",
            "symbol": "RUB",
            "symbol-alt-variant": "₽"
          },
          "RUR": {
            "displayName": "ruski rubelj (1991–1998)",
            "symbol": "RUR",
            "symbol-alt-narrow": "р."
          },
          "RWF": {
            "displayName": "ruandski frank",
            "displayName-count-one": "ruandski frank",
            "displayName-count-two": "ruandski frank",
            "displayName-count-few": "ruandski frank",
            "displayName-count-other": "ruandski frank",
            "symbol": "RWF",
            "symbol-alt-narrow": "RF"
          },
          "SAR": {
            "displayName": "saudski rial",
            "displayName-count-one": "saudski rial",
            "displayName-count-two": "saudski rial",
            "displayName-count-few": "saudski rial",
            "displayName-count-other": "saudski rial",
            "symbol": "SAR"
          },
          "SBD": {
            "displayName": "solomonski dolar",
            "displayName-count-one": "solomonski dolar",
            "displayName-count-two": "solomonski dolar",
            "displayName-count-few": "solomonski dolar",
            "displayName-count-other": "solomonski dolar",
            "symbol": "SBD",
            "symbol-alt-narrow": "$"
          },
          "SCR": {
            "displayName": "sejšelska rupija",
            "displayName-count-one": "sejšelska rupija",
            "displayName-count-two": "sejšelska rupija",
            "displayName-count-few": "sejšelska rupija",
            "displayName-count-other": "sejšelska rupija",
            "symbol": "SCR"
          },
          "SDD": {
            "displayName": "stari sudanski dinar",
            "symbol": "SDD"
          },
          "SDG": {
            "displayName": "sudanski funt",
            "displayName-count-one": "sudanski funt",
            "displayName-count-two": "sudanski funt",
            "displayName-count-few": "sudanski funt",
            "displayName-count-other": "sudanski funt",
            "symbol": "SDG"
          },
          "SDP": {
            "displayName": "stari sudanski funt",
            "symbol": "SDP"
          },
          "SEK": {
            "displayName": "švedska krona",
            "displayName-count-one": "švedska krona",
            "displayName-count-two": "švedska krona",
            "displayName-count-few": "švedska krona",
            "displayName-count-other": "švedska krona",
            "symbol": "SEK",
            "symbol-alt-narrow": "kr"
          },
          "SGD": {
            "displayName": "singapurski dolar",
            "displayName-count-one": "singapurski dolar",
            "displayName-count-two": "singapurski dolar",
            "displayName-count-few": "singapurski dolar",
            "displayName-count-other": "singapurski dolar",
            "symbol": "SGD",
            "symbol-alt-narrow": "$"
          },
          "SHP": {
            "displayName": "funt Sv. Helene",
            "displayName-count-one": "funt Sv. Helene",
            "displayName-count-two": "funt Sv. Helene",
            "displayName-count-few": "funt Sv. Helene",
            "displayName-count-other": "funt Sv. Helene",
            "symbol": "SHP",
            "symbol-alt-narrow": "£"
          },
          "SIT": {
            "displayName": "slovenski tolar",
            "displayName-count-one": "slovenski tolar",
            "displayName-count-two": "slovenska tolarja",
            "displayName-count-few": "slovenski tolarji",
            "displayName-count-other": "slovenskih tolarjev",
            "symbol": "SIT"
          },
          "SKK": {
            "displayName": "slovaška krona",
            "displayName-count-one": "slovaška krona",
            "displayName-count-two": "slovaški kroni",
            "displayName-count-few": "slovaške krone",
            "displayName-count-other": "slovaških kron",
            "symbol": "SKK"
          },
          "SLL": {
            "displayName": "sieraleonski leone",
            "displayName-count-one": "sieraleonski leone",
            "displayName-count-two": "sieraleonski leone",
            "displayName-count-few": "sieraleonski leone",
            "displayName-count-other": "sieraleonski leone",
            "symbol": "SLL"
          },
          "SOS": {
            "displayName": "somalski šiling",
            "displayName-count-one": "somalski šiling",
            "displayName-count-two": "somalski šiling",
            "displayName-count-few": "somalski šiling",
            "displayName-count-other": "somalski šiling",
            "symbol": "SOS"
          },
          "SRD": {
            "displayName": "surinamski dolar",
            "displayName-count-one": "surinamski dolar",
            "displayName-count-two": "surinamski dolar",
            "displayName-count-few": "surinamski dolar",
            "displayName-count-other": "surinamski dolar",
            "symbol": "SRD",
            "symbol-alt-narrow": "$"
          },
          "SRG": {
            "displayName": "surinamski gulden",
            "symbol": "SRG"
          },
          "SSP": {
            "displayName": "južnosudanski funt",
            "displayName-count-one": "južnosudanski funt",
            "displayName-count-two": "južnosudanska funta",
            "displayName-count-few": "južnosudanski funti",
            "displayName-count-other": "južnosudanskih funtov",
            "symbol": "SSP",
            "symbol-alt-narrow": "£"
          },
          "STD": {
            "displayName": "saotomejska dobra",
            "displayName-count-one": "saotomejska dobra",
            "displayName-count-two": "saotomejska dobra",
            "displayName-count-few": "saotomejska dobra",
            "displayName-count-other": "saotomejska dobra",
            "symbol": "STD",
            "symbol-alt-narrow": "Db"
          },
          "SUR": {
            "displayName": "sovjetski rubelj",
            "symbol": "SUR"
          },
          "SVC": {
            "displayName": "salvadorski kolon",
            "symbol": "SVC"
          },
          "SYP": {
            "displayName": "sirijski funt",
            "displayName-count-one": "sirijski funt",
            "displayName-count-two": "sirijski funt",
            "displayName-count-few": "sirijski funt",
            "displayName-count-other": "sirijski funt",
            "symbol": "SYP",
            "symbol-alt-narrow": "£"
          },
          "SZL": {
            "displayName": "svazijski lilangeni",
            "displayName-count-one": "svazijski lilangeni",
            "displayName-count-two": "svazijski lilangeni",
            "displayName-count-few": "svazijski lilangeni",
            "displayName-count-other": "svazijski lilangeni",
            "symbol": "SZL"
          },
          "THB": {
            "displayName": "tajski baht",
            "displayName-count-one": "tajski baht",
            "displayName-count-two": "tajski baht",
            "displayName-count-few": "tajski baht",
            "displayName-count-other": "tajski baht",
            "symbol": "฿",
            "symbol-alt-narrow": "฿"
          },
          "TJR": {
            "displayName": "tadžikistanski rubelj",
            "symbol": "TJR"
          },
          "TJS": {
            "displayName": "tadžikistanski somoni",
            "displayName-count-one": "tadžikistanski somoni",
            "displayName-count-two": "tadžikistanski somoni",
            "displayName-count-few": "tadžikistanski somoni",
            "displayName-count-other": "tadžikistanski somoni",
            "symbol": "TJS"
          },
          "TMM": {
            "displayName": "turkmenski manat",
            "symbol": "TMM"
          },
          "TMT": {
            "displayName": "turkmenistanski novi manat",
            "displayName-count-one": "turkmenistanski novi manat",
            "displayName-count-two": "turkmenistanski novi manat",
            "displayName-count-few": "turkmenistanski novi manat",
            "displayName-count-other": "turkmenistanski novi manat",
            "symbol": "TMT"
          },
          "TND": {
            "displayName": "tunizijski dinar",
            "displayName-count-one": "tunizijski dinar",
            "displayName-count-two": "tunizijski dinar",
            "displayName-count-few": "tunizijski dinar",
            "displayName-count-other": "tunizijski dinar",
            "symbol": "TND"
          },
          "TOP": {
            "displayName": "tongovska paanga",
            "displayName-count-one": "tongovska paanga",
            "displayName-count-two": "tongovska paanga",
            "displayName-count-few": "tongovska paanga",
            "displayName-count-other": "tongovska paanga",
            "symbol": "TOP",
            "symbol-alt-narrow": "T$"
          },
          "TPE": {
            "displayName": "timorski eskudo",
            "symbol": "TPE"
          },
          "TRL": {
            "displayName": "stara turška lira",
            "symbol": "TRL"
          },
          "TRY": {
            "displayName": "nova turška lira",
            "displayName-count-one": "nova turška lira",
            "displayName-count-two": "nova turška lira",
            "displayName-count-few": "nova turška lira",
            "displayName-count-other": "nova turška lira",
            "symbol": "TRY",
            "symbol-alt-narrow": "₺",
            "symbol-alt-variant": "TL"
          },
          "TTD": {
            "displayName": "dolar Trinidada in Tobaga",
            "displayName-count-one": "dolar Trinidada in Tobaga",
            "displayName-count-two": "dolar Trinidada in Tobaga",
            "displayName-count-few": "dolar Trinidada in Tobaga",
            "displayName-count-other": "dolar Trinidada in Tobaga",
            "symbol": "TTD",
            "symbol-alt-narrow": "$"
          },
          "TWD": {
            "displayName": "novi tajvanski dolar",
            "displayName-count-one": "novi tajvanski dolar",
            "displayName-count-two": "novi tajvanski dolar",
            "displayName-count-few": "novi tajvanski dolar",
            "displayName-count-other": "novi tajvanski dolar",
            "symbol": "NT$",
            "symbol-alt-narrow": "NT$"
          },
          "TZS": {
            "displayName": "tanzanijski šiling",
            "displayName-count-one": "tanzanijski šiling",
            "displayName-count-two": "tanzanijski šiling",
            "displayName-count-few": "tanzanijski šiling",
            "displayName-count-other": "tanzanijski šiling",
            "symbol": "TZS"
          },
          "UAH": {
            "displayName": "ukrajinska grivna",
            "displayName-count-one": "ukrajinska grivna",
            "displayName-count-two": "ukrajinska grivna",
            "displayName-count-few": "ukrajinska grivna",
            "displayName-count-other": "ukrajinska grivna",
            "symbol": "UAH",
            "symbol-alt-narrow": "₴"
          },
          "UAK": {
            "displayName": "ukrajinski karbovanci",
            "symbol": "UAK"
          },
          "UGS": {
            "displayName": "stari ugandski šiling (1966–1987)",
            "symbol": "UGS"
          },
          "UGX": {
            "displayName": "ugandski šiling",
            "displayName-count-one": "ugandski šiling",
            "displayName-count-two": "ugandski šiling",
            "displayName-count-few": "ugandski šiling",
            "displayName-count-other": "ugandski šiling",
            "symbol": "UGX"
          },
          "USD": {
            "displayName": "ameriški dolar",
            "displayName-count-one": "ameriški dolar",
            "displayName-count-two": "ameriška dolarja",
            "displayName-count-few": "ameriški dolarji",
            "displayName-count-other": "ameriških dolarjev",
            "symbol": "$",
            "symbol-alt-narrow": "$"
          },
          "USN": {
            "displayName": "ameriški dolar, naslednji dan",
            "symbol": "USN"
          },
          "USS": {
            "displayName": "ameriški dolar, isti dan",
            "symbol": "USS"
          },
          "UYI": {
            "displayName": "UYI",
            "symbol": "UYI"
          },
          "UYP": {
            "displayName": "stari urugvajski peso (1975–1993)",
            "symbol": "UYP"
          },
          "UYU": {
            "displayName": "urugvajski peso",
            "displayName-count-one": "urugvajski peso",
            "displayName-count-two": "urugvajski peso",
            "displayName-count-few": "urugvajski peso",
            "displayName-count-other": "urugvajski peso",
            "symbol": "UYU",
            "symbol-alt-narrow": "$"
          },
          "UZS": {
            "displayName": "uzbeški sum",
            "displayName-count-one": "uzbeški sum",
            "displayName-count-two": "uzbeški sum",
            "displayName-count-few": "uzbeški sum",
            "displayName-count-other": "uzbeški sum",
            "symbol": "UZS"
          },
          "VEB": {
            "displayName": "venezuelski bolivar (1871–2008)",
            "symbol": "VEB"
          },
          "VEF": {
            "displayName": "venezuelski bolivar",
            "displayName-count-one": "venezuelski bolivar",
            "displayName-count-two": "venezuelski bolivar",
            "displayName-count-few": "venezuelski bolivar",
            "displayName-count-other": "venezuelski bolivar",
            "symbol": "VEF",
            "symbol-alt-narrow": "Bs"
          },
          "VND": {
            "displayName": "vientnamski dong",
            "displayName-count-one": "vientnamski dong",
            "displayName-count-two": "vientnamski dong",
            "displayName-count-few": "vientnamski dong",
            "displayName-count-other": "vientnamski dong",
            "symbol": "₫",
            "symbol-alt-narrow": "₫"
          },
          "VNN": {
            "displayName": "VNN",
            "symbol": "VNN"
          },
          "VUV": {
            "displayName": "vanuatujski vatu",
            "displayName-count-one": "vanuatujski vatu",
            "displayName-count-two": "vanuatujski vatu",
            "displayName-count-few": "vanuatujski vatu",
            "displayName-count-other": "vanuatujski vatu",
            "symbol": "VUV"
          },
          "WST": {
            "displayName": "samoanska tala",
            "displayName-count-one": "samoanska tala",
            "displayName-count-two": "samoanska tala",
            "displayName-count-few": "samoanska tala",
            "displayName-count-other": "samoanska tala",
            "symbol": "WST"
          },
          "XAF": {
            "displayName": "CFA frank BEAC",
            "displayName-count-one": "CFA frank BEAC",
            "displayName-count-two": "CFA frank BEAC",
            "displayName-count-few": "CFA frank BEAC",
            "displayName-count-other": "CFA frank BEAC",
            "symbol": "FCFA"
          },
          "XAG": {
            "displayName": "srebro",
            "symbol": "XAG"
          },
          "XAU": {
            "displayName": "zlato",
            "symbol": "XAU"
          },
          "XBA": {
            "displayName": "evropska sestavljena enota",
            "symbol": "XBA"
          },
          "XBB": {
            "displayName": "evropska monetarna enota",
            "symbol": "XBB"
          },
          "XBC": {
            "displayName": "evropska obračunska enota (XBC)",
            "symbol": "XBC"
          },
          "XBD": {
            "displayName": "evropska obračunska enota (XBD)",
            "symbol": "XBD"
          },
          "XCD": {
            "displayName": "vzhodnokaribski dolar",
            "displayName-count-one": "vzhodnokaribski dolar",
            "displayName-count-two": "vzhodnokaribski dolar",
            "displayName-count-few": "vzhodnokaribski dolar",
            "displayName-count-other": "vzhodnokaribski dolar",
            "symbol": "EC$",
            "symbol-alt-narrow": "$"
          },
          "XDR": {
            "displayName": "posebne pravice črpanja",
            "symbol": "XDR"
          },
          "XEU": {
            "displayName": "evropska denarna enota",
            "symbol": "XEU"
          },
          "XFO": {
            "displayName": "zlati frank",
            "symbol": "XFO"
          },
          "XFU": {
            "displayName": "frank UIC",
            "symbol": "XFU"
          },
          "XOF": {
            "displayName": "CFA frank BCEAO",
            "displayName-count-one": "CFA frank BCEAO",
            "displayName-count-two": "CFA frank BCEAO",
            "displayName-count-few": "CFA frank BCEAO",
            "displayName-count-other": "CFA frank BCEAO",
            "symbol": "CFA"
          },
          "XPD": {
            "displayName": "paladij",
            "symbol": "XPD"
          },
          "XPF": {
            "displayName": "CFP frank",
            "displayName-count-one": "CFP frank",
            "displayName-count-two": "CFP frank",
            "displayName-count-few": "CFP frank",
            "displayName-count-other": "CFP frank",
            "symbol": "CFPF"
          },
          "XPT": {
            "displayName": "platina",
            "symbol": "XPT"
          },
          "XRE": {
            "displayName": "XRE",
            "symbol": "XRE"
          },
          "XSU": {
            "displayName": "XSU",
            "symbol": "XSU"
          },
          "XTS": {
            "displayName": "koda za potrebe testiranja",
            "symbol": "XTS"
          },
          "XUA": {
            "displayName": "XUA",
            "symbol": "XUA"
          },
          "XXX": {
            "displayName": "neznana ali neveljavna valuta",
            "displayName-count-one": "neznana ali neveljavna valuta",
            "displayName-count-two": "neznana ali neveljavna valuta",
            "displayName-count-few": "neznana ali neveljavna valuta",
            "displayName-count-other": "neznana ali neveljavna valuta",
            "symbol": "XXX"
          },
          "YDD": {
            "displayName": "jemenski dinar",
            "symbol": "YDD"
          },
          "YER": {
            "displayName": "jemenski rial",
            "displayName-count-one": "jemenski rial",
            "displayName-count-two": "jemenski rial",
            "displayName-count-few": "jemenski rial",
            "displayName-count-other": "jemenski rial",
            "symbol": "YER"
          },
          "YUD": {
            "displayName": "stari jugoslovanski dinar",
            "symbol": "YUD"
          },
          "YUM": {
            "displayName": "novi jugoslovanski dinar",
            "symbol": "YUM"
          },
          "YUN": {
            "displayName": "jugoslovanski konvertibilni dinar",
            "symbol": "YUN"
          },
          "YUR": {
            "displayName": "YUR",
            "symbol": "YUR"
          },
          "ZAL": {
            "displayName": "južnoafriški finančni rand",
            "symbol": "ZAL"
          },
          "ZAR": {
            "displayName": "južnoafriški rand",
            "displayName-count-one": "južnoafriški rand",
            "displayName-count-two": "južnoafriški rand",
            "displayName-count-few": "južnoafriški rand",
            "displayName-count-other": "južnoafriški rand",
            "symbol": "ZAR",
            "symbol-alt-narrow": "R"
          },
          "ZMK": {
            "displayName": "zambijska kvača (1968–2012)",
            "symbol": "ZMK"
          },
          "ZMW": {
            "displayName": "zambijska kvača",
            "displayName-count-one": "zambijska kvača",
            "displayName-count-two": "zambijska kvača",
            "displayName-count-few": "zambijska kvača",
            "displayName-count-other": "zambijska kvača",
            "symbol": "ZMW",
            "symbol-alt-narrow": "ZK"
          },
          "ZRN": {
            "displayName": "zairski novi zaire",
            "symbol": "ZRN"
          },
          "ZRZ": {
            "displayName": "zairski zaire",
            "symbol": "ZRZ"
          },
          "ZWD": {
            "displayName": "zimbabvejski dolar",
            "symbol": "ZWD"
          },
          "ZWL": {
            "displayName": "zimbabvejski dolar (2009)",
            "symbol": "ZWL"
          },
          "ZWR": {
            "displayName": "ZWR",
            "symbol": "ZWR"
          }
        }
      }
    }
  }
}
)