Globalize.load({
  "main": {
    "sl": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "root"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0} ({1})",
          "localeSeparator": "{0}, {1}",
          "localeKeyTypePattern": "{0}: {1}"
        },
        "keys": {
          "calendar": "koledar",
          "colAlternate": "Razvrščanje s prezrtimi znaki",
          "colBackwards": "Razvrščanje z obratnimi naglasi",
          "colCaseFirst": "Razvrščanje velike črke/male črke",
          "colCaseLevel": "Razvrščanje, občutljivo na velike/male črke",
          "colHiraganaQuaternary": "Razvrščanje kana",
          "colNormalization": "Normalizirano razvrščanje",
          "colNumeric": "Številsko razvrščanje",
          "colStrength": "Moč razvrščanja",
          "collation": "razvrščanje",
          "currency": "valuta",
          "numbers": "Številke",
          "timezone": "Časovni pas",
          "va": "Različica območnih nastavitev",
          "variableTop": "Razvrščanje kot simboli",
          "x": "Private-Use"
        },
        "types": {
          "numbers": {
            "arab": "Arabskoindijske števke",
            "arabext": "Razširjene arabskoindijske števke",
            "armn": "Armenske številke",
            "armnlow": "Armenske majhne številke",
            "bali": "bali",
            "beng": "Bengalske števke"
          },
          "collation": {
            "big5han": "razvrščanje po sistemu tradicionalne kitajščine - Big5"
          },
          "numbers": {
            "brah": "brah"
          },
          "calendar": {
            "buddhist": "budistični koledar"
          },
          "numbers": {
            "cakm": "cakm",
            "cham": "cham"
          },
          "calendar": {
            "chinese": "kitajski koledar",
            "coptic": "Koptski koledar",
            "dangi": "stari korejski koledar"
          },
          "numbers": {
            "deva": "Devangarske števke"
          },
          "collation": {
            "dictionary": "Vrstni red razvrščanja v slovarju",
            "ducet": "Privzeto razvrščanje Unicode",
            "eor": "eor"
          },
          "numbers": {
            "ethi": "Etiopijske številke"
          },
          "calendar": {
            "ethiopic": "Etiopski koledar",
            "ethiopic-amete-alem": "Etiopsko ametsko alemski koledar"
          },
          "numbers": {
            "finance": "Finančne številke",
            "fullwide": "Števke polne širine"
          },
          "collation": {
            "gb2312han": "razvrščanje po sistemu poenostavljene kitajščine - GB2312"
          },
          "numbers": {
            "geor": "Gruzijske številke"
          },
          "calendar": {
            "gregorian": "gregorijanski koledar"
          },
          "numbers": {
            "grek": "Grške številke",
            "greklow": "Grške male številke",
            "gujr": "Gudžaratske števke",
            "guru": "Gurmuške števke",
            "hanidec": "Kitajske decimalne številke",
            "hans": "Poenostavljene kitajske številke",
            "hansfin": "Poenostavljene kitajske finančne številke",
            "hant": "Tradicionalne kitajske številke",
            "hantfin": "Tradicionalne kitajske finančne številke",
            "hebr": "Hebrejske številke"
          },
          "calendar": {
            "hebrew": "hebrejski koledar"
          },
          "colStrength": {
            "identical": "Razvrščanje vsega"
          },
          "calendar": {
            "indian": "indijanski koledar",
            "islamic": "islamski koledar",
            "islamic-civil": "islamski civilni koledar",
            "islamic-rgsa": "islamic-rgsa",
            "islamic-tbla": "islamic-tbla",
            "islamic-umalqura": "islamic-umalqura",
            "iso8601": "koledar ISO-8601",
            "japanese": "japonski koledar"
          },
          "numbers": {
            "java": "java",
            "jpan": "Japonske številke",
            "jpanfin": "Japonske finančne številke",
            "kali": "kali",
            "khmr": "Kmerske števke",
            "knda": "Kanaredske števke",
            "lana": "lana",
            "lanatham": "lanatham",
            "laoo": "Laoške števke",
            "latn": "Zahodne števke",
            "lepc": "lepc",
            "limb": "limb"
          },
          "colCaseFirst": {
            "lower": "Razvrščanje malih črk najprej"
          },
          "numbers": {
            "mlym": "Malajalamske števke",
            "mong": "Mongolske števke",
            "mtei": "mtei",
            "mymr": "Mjanmarske števke",
            "mymrshan": "mymrshan",
            "native": "Domače števke",
            "nkoo": "nkoo"
          },
          "colBackwards": {
            "no": "Navadno razvrščanje naglasov"
          },
          "colCaseFirst": {
            "no": "Razvrščanje v običajnem zaporedju velikih/malih črk"
          },
          "colCaseLevel": {
            "no": "Razvrščanje ne glede na velike/male črke"
          },
          "colHiraganaQuaternary": {
            "no": "Razvrščanje kana ločeno"
          },
          "colNormalization": {
            "no": "Razvrščanje brez normaliziranja"
          },
          "colNumeric": {
            "no": "Ločeno razvrščanje številk"
          },
          "colAlternate": {
            "non-ignorable": "Razvrščanje simbolov"
          },
          "numbers": {
            "olck": "olck",
            "orya": "Orijske števke",
            "osma": "osma"
          },
          "calendar": {
            "persian": "Perzijski koledar"
          },
          "collation": {
            "phonebook": "razvrščanje po abecedi",
            "phonetic": "Fonetično razvrščanje",
            "pinyin": "razvrščanje po sistemu pinjin"
          },
          "colStrength": {
            "primary": "Razvrščanje samo osnovnih črk",
            "quaternary": "Razvrščanje po naglasih/velikih črkah/malih črkah/širini/kana"
          },
          "collation": {
            "reformed": "Reformirano razvrščanje"
          },
          "calendar": {
            "roc": "kitajski državni koledar"
          },
          "numbers": {
            "roman": "Rimske številke",
            "romanlow": "Rimske male številke",
            "saur": "saur"
          },
          "collation": {
            "search": "Splošno iskanje",
            "searchjl": "Iskanje po začetnem soglasniku hangul"
          },
          "colStrength": {
            "secondary": "Razvrščanje naglasov"
          },
          "colAlternate": {
            "shifted": "Razvrščanje s prezrtjem simbolov"
          },
          "numbers": {
            "shrd": "shrd",
            "sora": "sora"
          },
          "collation": {
            "standard": "Standardno razvrščanje",
            "stroke": "razvrščanje po zaporedju pisanja pismenk"
          },
          "numbers": {
            "sund": "sund",
            "takr": "takr",
            "talu": "talu",
            "taml": "Tamilske številke",
            "tamldec": "Tamilske števke",
            "telu": "Teluške števke"
          },
          "colStrength": {
            "tertiary": "Razvrščanje po naglasih/velikih črkah/malih črkah/širini"
          },
          "numbers": {
            "thai": "Tajske števke",
            "tibt": "Tibetanske števke"
          },
          "collation": {
            "traditional": "razvrščanje po tradicionalnem sistemu"
          },
          "numbers": {
            "traditional": "Tradicionalne številke"
          },
          "collation": {
            "unihan": "Razvrščanje koren-poteza"
          },
          "colCaseFirst": {
            "upper": "Razvrščanje velikih črk najprej"
          },
          "numbers": {
            "vaii": "Številke vai"
          },
          "colBackwards": {
            "yes": "Obratno razvrščanje naglasov"
          },
          "colCaseLevel": {
            "yes": "Razvrščanje ob upoštevanju velikih/malih črk"
          },
          "colHiraganaQuaternary": {
            "yes": "Razvrščanje kana različno"
          },
          "colNormalization": {
            "yes": "Normalizirano razvrščanje Unicode"
          },
          "colNumeric": {
            "yes": "Številsko razvrščanje števk"
          },
          "collation": {
            "zhuyin": "zhuyin"
          }
        },
        "codePatterns": {
          "language": "Jezik: {0}",
          "script": "{0}",
          "territory": "Regija: {0}"
        }
      }
    }
  }
}
)