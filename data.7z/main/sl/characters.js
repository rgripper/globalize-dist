Globalize.load({
  "main": {
    "sl": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "root"
      },
      "characters": {
        "exemplarCharacters": "[a b c č d e f g h i j k l m n o p r s š t u v z ž]",
        "auxiliary": "[á à ă â å ä ā æ ç ć đ é è ĕ ê ë ē í ì ĭ î ï ī ñ ó ò ŏ ô ö ø ō œ q ú ù ŭ û ü ū w x y ÿ]",
        "punctuation": "[\\- , ; \\: ! ? . ( ) \\[ \\] \\{ \\}]",
        "index": "[A B C Č Ć D Đ E F G H I J K L M N O P Q R S Š T U V W X Y Z Ž]",
        "ellipsis": {
          "initial": "…{0}",
          "medial": "{0}…{1}",
          "final": "{0}…",
          "word-initial": "… {0}",
          "word-medial": "{0} … {1}",
          "word-final": "{0} …"
        },
        "moreInformation": "?"
      }
    }
  }
}
)