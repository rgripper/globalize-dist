Globalize.load({
  "main": {
    "ro": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "ro"
      },
      "localeDisplayNames": {
        "transformNames": {
          "BGN": "BGN",
          "Numeric": "Numeric",
          "Tone": "Ton",
          "UNGEGN": "UNGEGN",
          "x-Accents": "Accente",
          "x-Fullwidth": "Cu lățime întreagă",
          "x-Halfwidth": "Cu jumătate de lățime",
          "x-Jamo": "Jamo",
          "x-Pinyin": "Pinyin",
          "x-Publishing": "Publicare"
        }
      }
    }
  }
}
)