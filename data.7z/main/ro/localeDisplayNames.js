Globalize.load({
  "main": {
    "ro": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "ro"
      },
      "localeDisplayNames": {
        "localeDisplayPattern": {
          "localePattern": "{0} ({1})",
          "localeSeparator": "{0}, {1}",
          "localeKeyTypePattern": "{0}: {1}"
        },
        "keys": {
          "calendar": "calendar",
          "colAlternate": "Ordonare cu simbolurile ignorate",
          "colBackwards": "Ordonare inversă după accent",
          "colCaseFirst": "Ordonare după majuscule/minuscule",
          "colCaseLevel": "Ordonare care ține seama de majuscule/minuscule",
          "colHiraganaQuaternary": "Ordonare după kana",
          "colNormalization": "Ordonare normalizată",
          "colNumeric": "Ordonare numerică",
          "colStrength": "Puterea ordonării",
          "collation": "ordine de sortare",
          "currency": "monedă",
          "numbers": "numere",
          "timezone": "Fusul orar",
          "va": "Varianta locală",
          "variableTop": "Ordonați ca simboluri",
          "x": "Utilizare privată"
        },
        "types": {
          "numbers": {
            "arab": "cifre indo-arabe",
            "arabext": "cifre indo-arabe extinse",
            "armn": "numerale armenești",
            "armnlow": "numerale armenești cu minuscule",
            "bali": "bali",
            "beng": "cifre bengaleze"
          },
          "collation": {
            "big5han": "sortare pentru chineza tradițională - Big5"
          },
          "numbers": {
            "brah": "brah"
          },
          "calendar": {
            "buddhist": "calendar budist"
          },
          "numbers": {
            "cakm": "cakm",
            "cham": "cham"
          },
          "calendar": {
            "chinese": "calendar chinezesc",
            "coptic": "calendar copt",
            "dangi": "calendar dangi"
          },
          "numbers": {
            "deva": "cifre devanagari"
          },
          "collation": {
            "dictionary": "Ordine de sortare a dicționarului",
            "ducet": "ordine de sortare Unicode implicită",
            "eor": "regulile europene de sortare"
          },
          "numbers": {
            "ethi": "numerale etiopiene"
          },
          "calendar": {
            "ethiopic": "calendar etiopian",
            "ethiopic-amete-alem": "Calendarul etiopian amete alem"
          },
          "numbers": {
            "finance": "Sistemul numeric financiar",
            "fullwide": "cifre cu lățimea întreagă"
          },
          "collation": {
            "gb2312han": "sortare pentru chineza simplificată - GB2312"
          },
          "numbers": {
            "geor": "numerale georgiene"
          },
          "calendar": {
            "gregorian": "calendar gregorian"
          },
          "numbers": {
            "grek": "numerale grecești",
            "greklow": "numerale grecești cu minuscule",
            "gujr": "cifre gujarati",
            "guru": "cifre gurmukhi",
            "hanidec": "numerale zecimale chinezești",
            "hans": "numerale chinezești simplificate",
            "hansfin": "numerale financiare chinezești simplificate",
            "hant": "numerale chinezești tradiționale",
            "hantfin": "numerale financiare chinezești tradiționale",
            "hebr": "numerale ebraice"
          },
          "calendar": {
            "hebrew": "calendar ebraic"
          },
          "colStrength": {
            "identical": "Ordonați-le pe toate"
          },
          "calendar": {
            "indian": "calendar național indian",
            "islamic": "calendar islamic",
            "islamic-civil": "calendar islamic civil",
            "islamic-rgsa": "islamic-rgsa",
            "islamic-tbla": "islamic-tbla",
            "islamic-umalqura": "islamic-umalqura",
            "iso8601": "calendar ISO-8601",
            "japanese": "calendar japonez"
          },
          "numbers": {
            "java": "java",
            "jpan": "numerale japoneze",
            "jpanfin": "numerale financiare japoneze",
            "kali": "kali",
            "khmr": "cifre khmere",
            "knda": "cifre kannada",
            "lana": "lana",
            "lanatham": "lanatham",
            "laoo": "cifre laoțiene",
            "latn": "cifre occidentale",
            "lepc": "lepc",
            "limb": "limb"
          },
          "colCaseFirst": {
            "lower": "Ordonați întâi minusculele"
          },
          "numbers": {
            "mlym": "cifre malayalam",
            "mong": "Cifre mongole",
            "mtei": "mtei",
            "mymr": "cifre birmaneze",
            "mymrshan": "mymrshan",
            "native": "Cifre native",
            "nkoo": "nkoo"
          },
          "colBackwards": {
            "no": "Ordonați accentele în mod normal"
          },
          "colCaseFirst": {
            "no": "Ordonați după dimensiunea normală a literei"
          },
          "colCaseLevel": {
            "no": "Ordonați neținând seama de diferența dintre majuscule/minuscule"
          },
          "colHiraganaQuaternary": {
            "no": "Ordonați caracterele kana separat"
          },
          "colNormalization": {
            "no": "Ordonați fără normalizare"
          },
          "colNumeric": {
            "no": "Ordonați cifrele individual"
          },
          "colAlternate": {
            "non-ignorable": "Ordonați simbolurile"
          },
          "numbers": {
            "olck": "olck",
            "orya": "cifre oriya",
            "osma": "osma"
          },
          "calendar": {
            "persian": "calendar persan"
          },
          "collation": {
            "phonebook": "sortare după cartea de telefon",
            "phonetic": "Tip de ordonare fonetică",
            "pinyin": "sortare pinyin"
          },
          "colStrength": {
            "primary": "Ordonați numai literele de bază",
            "quaternary": "Ordonați după accente/dimensiunea literei/lățime/kana"
          },
          "collation": {
            "reformed": "Ordine de sortare reformată"
          },
          "calendar": {
            "roc": "calendarul Republicii Chineze"
          },
          "numbers": {
            "roman": "numerale romane",
            "romanlow": "numerale romane cu minuscule",
            "saur": "saur"
          },
          "collation": {
            "search": "căutare cu scop general",
            "searchjl": "Căutați în funcție de consoana inițială hangul"
          },
          "colStrength": {
            "secondary": "Ordonați după accent"
          },
          "colAlternate": {
            "shifted": "Ordonați ignorând simbolurile"
          },
          "numbers": {
            "shrd": "shrd",
            "sora": "sora"
          },
          "collation": {
            "standard": "ordine de sortare standard",
            "stroke": "ordine de sortare după trasare"
          },
          "numbers": {
            "sund": "sund",
            "takr": "takr",
            "talu": "talu",
            "taml": "numerale tradiționale tamilă",
            "tamldec": "cifre tamile",
            "telu": "cifre telugu"
          },
          "colStrength": {
            "tertiary": "Ordonați după accente/dimensiunea literei/lățime"
          },
          "numbers": {
            "thai": "cifre thailandeze",
            "tibt": "cifre tibetane"
          },
          "collation": {
            "traditional": "sortare tradițională"
          },
          "numbers": {
            "traditional": "Numere tradiționale"
          },
          "collation": {
            "unihan": "Ordine de sortare a liniilor ideogramelor"
          },
          "colCaseFirst": {
            "upper": "Ordonați mai întâi majusculele"
          },
          "numbers": {
            "vaii": "Cifre Vai"
          },
          "colBackwards": {
            "yes": "Ordonați după accente în ordine inversă"
          },
          "colCaseLevel": {
            "yes": "Ordonați ținând seama de diferența dintre majuscule/minuscule"
          },
          "colHiraganaQuaternary": {
            "yes": "Ordonați kana diferențiat"
          },
          "colNormalization": {
            "yes": "Ordonați caracterele unicode normalizat"
          },
          "colNumeric": {
            "yes": "Ordonați cifrele în ordine numerică"
          },
          "collation": {
            "zhuyin": "zhuyin"
          }
        },
        "codePatterns": {
          "language": "Limbă: {0}",
          "script": "Scriere: {0}",
          "territory": "Regiune: {0}"
        }
      }
    }
  }
}
)