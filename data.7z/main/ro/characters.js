Globalize.load({
  "main": {
    "ro": {
      "identity": {
        "version": {
          "_cldrVersion": "26",
          "_number": "$Revision: 10809 $"
        },
        "generation": {
          "_date": "$Date: 2014-08-14 15:10:07 -0500 (Thu, 14 Aug 2014) $"
        },
        "language": "ro"
      },
      "characters": {
        "exemplarCharacters": "[a ă â b c d e f g h i î j k l m n o p r s ș t ț u v x z]",
        "auxiliary": "[á à å ä ç é è ê ë ñ ö q ş ţ ü w y]",
        "punctuation": "[\\- ‐ – — , ; \\: ! ? . … ' ‘ \" “ ” „ « » ( ) \\[ \\] @ * /]",
        "index": "[A Ă Â B C D E F G H I Î J K L M N O P Q R S Ș T Ț U V W X Y Z]",
        "ellipsis": {
          "initial": "…{0}",
          "medial": "{0}…{1}",
          "final": "{0}…",
          "word-initial": "…{0}",
          "word-medial": "{0} … {1}",
          "word-final": "{0}…"
        },
        "moreInformation": "..."
      }
    }
  }
}
)